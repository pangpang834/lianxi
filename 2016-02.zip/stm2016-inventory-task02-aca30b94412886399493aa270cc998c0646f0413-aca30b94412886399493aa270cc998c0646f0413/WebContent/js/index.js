

var stocks;
//d();
//
//draw();

// 検索ボックス作成
//function d(){
var ss=alasql('SELECT * FROM stock;');
var rows = alasql('SELECT * FROM whouse;');
for (var i = 0; i < rows.length; i++) {
	var row = rows[i];
	var option = $('<option>');
	option.attr('value', row.whouse.id);
	option.text(row.whouse.name);
	$('select[name="q1"]').append(option);
}

var rows = alasql('SELECT * FROM kind;');
for (var i = 0; i < rows.length; i++) {
	var row = rows[i];
	var option = $('<option>');
	option.attr('value', row.kind.id);
	option.text(row.kind.text);
	$('select[name="q2"]').append(option);
}

// 検索条件の取得
var q1 = parseInt($.url().param('q1') || '0');
$('select[name="q1"]').val(q1);
var q2 = parseInt($.url().param('q2') || '0');
$('select[name="q2"]').val(q2);
var q3 = $.url().param('q3') || '';
$('input[name="q3"]').val(q3);

// SQLの生成
var sql = 'SELECT * \
	FROM stock \
	JOIN whouse ON whouse.id = stock.whouse \
	JOIN item ON item.id = stock.item \
	JOIN kind ON kind.id = item.kind \
	WHERE item.code LIKE ? ';

sql += q1 ? 'AND whouse.id = ' + q1 + ' ' : '';
sql += q2 ? 'AND kind.id = ' + q2 + ' ' : '';

// SQL実行
stocks = alasql(sql, [ q3 + '%' ]);

//};

function pr2(a){
//	return (Myth.floor(a*10000))/100;
	return a*100;
};
// HTML作成
//function draw(){

var res = alasql('SELECT stock,SUM(qty) AS qty FROM trans WHERE qty < 0 GROUP BY stock ');
//
//var oldday = new Date(2017,0,1);
//var newday = new Date();
//var dif=Math.floor((newday-oldday)/1000/60/60/24);
dif=90;

var tbody = $('#tbody-stocks');
var idd=0;

for (var i = 0; i < stocks.length; i++) {
	var id=i+1;
	var tm = parseInt($.cookie(i.toString()));

	var smax=alasql("Select MAX(balance) AS a FROM trans WHERE stock=?", [ id ])[0].a;	
//	var at=alasql("Select balance AS a FROM stock WHERE id=?", [ id ]);	
	var at=alasql("Select balance AS a FROM stock WHERE id=?", [ id ])[0].a;	
//	var at=alasql("Select balance AS a FROM stock WHERE stock=?", [ id ])[0].a;	
	if(tm+at>smax){smax=tm+at;$.cookie("max"+id.toString()),tm+at;}
	
	
	var stockk = alasql('SELECT * FROM stock WHERE id = ?', [ id ]);
	var s=stockk[0].stock.seta;
	var s1=stockk[0].stock.sett;
	var s2=stockk[0].stock.settt;
	var s3=stockk[0].stock.setttt;
	var ba=stockk[0].stock.balance;
	var dif=90;
//	var sum = res[i].qty||0;
	try {
		var sum = res[i].qty
		}
		catch (e) {
		  
		   var sum=0;
		}
	var op=0;
	var mark;
	var op=0;
	
	var bamax=ba/smax;
	if (bamax<0.05){bamax=0.05};
	if(ba<=s1){
		if (s=="1"){var l1="<div class='progress-bar progress-bar-danger' role='progressbar' style='width: "+pr2(bamax)+"%;'>"+ba+"</div>"}
		if(s=="2"){var l1="<div class='progress-bar progress-bar-danger progress-bar-striped active' role='progressbar' style='width: "+pr2(bamax)+"%;'>"+ba+"</div>"}}
	else {
		if (s=="1"){var l1="<div class='progress-bar progress-bar-success' role='progressbar' style='width: "+pr2(bamax)+"%;'>"+ba+"</div>"}
		if(s=="2"){
			if(dif%s3==0){var l1="<div class='progress-bar progress-bar-success progress-bar-striped active' role='progressbar' style='width: "+pr2(bamax)+"%;'>"+ba+"</div>"}
			else {var l1="<div class='progress-bar progress-bar-striped active' role='progressbar' style='width: "+pr2(bamax)+"%;'>"+ba+"</div>"}
	}}
	if(tm==0||isNaN(tm)){var l3="";
		if(s=="1" && (ba<(s1-sum/120*s2))){op= s3;l3="<div class='progress-bar progress-bar-warning' role='progressbar' style='width: "+pr2(s3/smax)+"%;'>"+s3+"</div>"}
		if(s=="2" && (dif%s3==0)){ 
			var pop=Math.floor(-(s3+s2)*sum/120+s1-ba);
			if (pop>0){op=pop;l3=l3="<div class='progress-bar progress-bar-warning progress-bar-striped active' role='progressbar' style='width: "+pr2(pop/smax)+"%;'>"+pop+"</div>"
	}}}
	else{
		if (s=="1"){var l3="<div class='progress-bar progress-bar-info' role='progressbar' style='width: "+pr2(tm/smax)+"%;'>"+tm+"</div>";}
		if(s=="2"){var l3="<div class='progress-bar progress-bar-info progress-bar-striped active' role='progressbar' style='width: "+pr2(tm/smax)+"%;'>"+tm+"</div>";}
	}	

	var l="<div style='width: 550px' class='progress'>"+l1+l3+"</div>";
//	var l="<div style='width: 550px' class='progress'></div>"
//	
//	style='width: 700px'
//	"<div class='progress'><div class='progress-bar' role='progressbar' style='width: "+20+"%;'>"+20+"</div>\
//	<div class='progress-bar progress-bar-success' role='progressbar' style='width: "+20+"%;'>"+20+"</div>\
//	<div class='progress-bar progress-bar-info progress-bar-striped active' role='progressbar' style='width: "+20+"%;'>"+20+"</div>\
//	<div class='progress-bar progress-bar-warning' role='progressbar' style='width: "+20+"%;'>"+20+"</div>\
//	<div class='progress-bar progress-bar-danger progress-bar-striped active' role='progressbar' style='width: "+20+"%;'>"+20+"</div></div>"
//		
	
	var stock = stocks[i];
	var tr = $('<tr id="sbb'+idd+'" ></tr>');
	tr.append('<td data-href="stock.html?id=' + stock.stock.id + '" id="ws'+idd+'">' + stock.whouse.name + '</td>');
	tr.append('<td data-href="stock.html?id=' + stock.stock.id + '">' + stock.kind.text + '</td>');
	tr.append('<td data-href="stock.html?id=' + stock.stock.id + '" id="ite'+idd+'">' + stock.item.code + '</td>');
	tr.append('<td data-href="stock.html?id=' + stock.stock.id + '" id="maker'+idd+'">' + stock.item.maker + '</td>');
	tr.append('<td data-href="stock.html?id=' + stock.stock.id + '" id="detail'+idd+'">' + stock.item.detail + '</td>');
	tr.append('<td data-href="stock.html?id=' + stock.stock.id + '" style="text-align: right;">' + numberWithCommas(stock.item.price) + '</td>');
	tr.append('<td data-href="stock.html?id=' + stock.stock.id + '" style="text-align: right;">' + stock.stock.balance + '</td>');
	tr.append('<td data-href="stock.html?id=' + stock.stock.id + '" id="short'+idd+'">' + stock.item.unit + '</td>');
	tr.append('<td data-href="stock.html?id=' + stock.stock.id + '" id="d'+idd+'">' + l + '</td>');
	tr.append('<td style="width: 130px;" data-href="#" name="ss" id="md'+idd+'"><input id="bbs'+idd+'" type="text" class="form-control" placeholder="number" value="'+op+'"></td>');
	
	
	
	tr.appendTo(tbody);
	idd++;
}


//
//for (var i = 0; i < stocks.length; i++) {
//	if($.cookie(i.toString())=="m"){
//	
//	var ma2=parseInt($("#bbs"+i+"").val());
//	
//	var op=0;
//	if(ma2!=0){
////	var markk=$("#markk"+i+"").val()?$("#markk"+i+"").val():"0";
////	var op=0;
////	if(markk!="0"){
//		$("#d"+i+"").remove();
//		$("#md"+i+"").remove();
//		$("#short"+i+"").after('<td id="md'+i+'"><input id="bbs'+i+'" type="text" class="form-control" placeholder="number" value="'+op+'"></td>');
//		$("#short"+i+"").after('<td><span class="label label-info">待ち</span></td>');
//	}}}


//}

//get today
function today(){
var day = new Date();
	    if ( day.getYear() >= 2000 ){ var year = day.getYear() }
	    else {  var year = day.getYear() +1900 }
	    var month = day.getMonth()+1;
	    var date = day.getDate();
	        if (month < 10) {    //月.日が一桁の時頭に0を付ける処理
	            month = "0" + month;	                         }
	        if (date < 10) {
	            date = "0" + date;	                        }
	        var time=year+'-'+month+'-'+date;
	        return time;
}

// クリック動作
//$('tbody > tr').css('cursor', 'pointer').on('click', function() {
//	window.location = $(this).attr('data-href');
//});
$('tbody > tr > td').on('click', function() {
	window.location = $(this).attr('data-href');
});

var s=alasql('SELECT * FROM orderr ');	

var stock_id = 0;;

$("#sticker").click(function () {
	if($("#preview-on").attr("class")=="btn btn-primary"){}
	else{
		if($("#preview-on").attr("class")=="btn btn-primar"){
		$("#preview-on").attr("class","btn btn-primary");}
		for (var i = 0; i < stocks.length; i++) {
			
			
			if($.cookie(i.toString())!="m"){
				
			
				
				
				
				
				
				
				
				
				
				
//			var ma1=$("#sbb"+i+"").text();
			var ma2=parseInt($("#bbs"+i+"").val());
			var wo=$("#ws"+i+"").text();
			var ite=$("#ite"+i+"").text();
			var maker=$("#maker"+i+"").text();
			var detail=$("#detail"+i+"").text();
			var comm="財務システムに通信";
			var time=today();
			var itee="["+ite+"]"+detail;

			if(ma2!=0){
				var id=i+1;
				
				alasql('INSERT INTO orderr VALUES(?,?,?,?,?);', [wo,itee,ma2,time,"w"]);	
				var tm1 = parseInt($.cookie(i.toString()))||0;
				
//				var att=alasql("Select balance AS a FROM stock WHERE id=?", [ id ]);	
				var att=alasql("Select balance AS a FROM stock WHERE id=?", [ id ])[0].a;	
				$.cookie(i.toString(),ma2+tm1);
				var s=alasql('SELECT * FROM orderr ');
				
				
				
				

				
				
				var tm = parseInt($.cookie(i.toString()));

				var smax=alasql("Select MAX(balance) AS a FROM trans WHERE stock=?", [ id ])[0].a;	
//				var cmax=$.cookie("max"+id.toString())||0;
				if(ma2+tm1+att>smax){smax=ma2+tm1+att;}
				$.cookie("max"+id.toString(),ma2+tm1+att)
				
				var stockk = alasql('SELECT * FROM stock WHERE id = ?', [ id ]);
				var s=stockk[0].stock.seta;
				var s1=stockk[0].stock.sett;
				var s2=stockk[0].stock.settt;
				var s3=stockk[0].stock.setttt;
				var ba=stockk[0].stock.balance;
				var dif=90;
//				var sum = res[i].qty||0;
				
				try {
					var sum = res[i].qty
					}
					catch (e) {
					  
					   var sum=0;
					}
				
				var op=0;
				var mark;
				var op=0;
				
				var bamax=ba/smax;
				if (bamax<0.05){bamax=0.05};
				if(ba<=s1){
					if (s=="1"){var l1="<div class='progress-bar progress-bar-danger' role='progressbar' style='width: "+pr2(bamax)+"%;'>"+ba+"</div>"}
					if(s=="2"){var l1="<div class='progress-bar progress-bar-danger progress-bar-striped active' role='progressbar' style='width: "+pr2(bamax)+"%;'>"+ba+"</div>"}}
				else {
					if (s=="1"){var l1="<div class='progress-bar progress-bar-success' role='progressbar' style='width: "+pr2(bamax)+"%;'>"+ba+"</div>"}
					if(s=="2"){
						if(dif%s3==0){var l1="<div class='progress-bar progress-bar-success progress-bar-striped active' role='progressbar' style='width: "+pr2(bamax)+"%;'>"+ba+"</div>"}
						else {var l1="<div class='progress-bar progress-bar-striped active' role='progressbar' style='width: "+pr2(bamax)+"%;'>"+ba+"</div>"}
				}}
				if(tm==0||isNaN(tm)){var l3="";
					if(s=="1" && (ba<(s1-sum/120*s2))){op= s3;l3="<div class='progress-bar progress-bar-warning' role='progressbar' style='width: "+pr2(s3/smax)+"%;'>"+s3+"</div>"}
					if(s=="2" && (dif%s3==0)){ 
						var pop=Math.floor(-(s3+s2)*sum/120+s1-ba);
						if (pop>0){op=pop;l3=l3="<div class='progress-bar progress-bar-warning progress-bar-striped active' role='progressbar' style='width: "+pr2(pop/smax)+"%;'>"+pop+"</div>"
				}}}
				else{
					if (s=="1"){var l3="<div class='progress-bar progress-bar-info' role='progressbar' style='width: "+pr2(tm/smax)+"%;'>"+tm+"</div>";}
					if(s=="2"){var l3="<div class='progress-bar progress-bar-info progress-bar-striped active' role='progressbar' style='width: "+pr2(tm/smax)+"%;'>"+tm+"</div>";}
				}	

				var l="<div style='width: 550px' class='progress'>"+l1+l3+"</div>";	
				
				
				$("#d"+i+"").remove();
				$("#short"+i+"").after('<td data-href="stock.html?id=' + stock.stock.id + '" id="d'+i+'">' + l + '</td>');
				$("#bbs"+i+"").val(0);
				
			}else{
			}
			
			}}


//					$("#d"+i+"").remove();
//					$("#md"+i+"").remove();
//					$("#short"+i+"").after('<td id="md'+i+'"><input id="bbs'+i+'" type="text" class="form-control" placeholder="number" value="'+op+'"></td>');
//					$("#short"+i+"").after('<td><span class="label label-info">待ち</span></td>');

//		alert("発注ができました。")
//	$("#re").click();
//	window.location.reload(true);
	
}});

if($("#preview-on").attr("class")=="btn btn-primary"){$("#sticker").click();}

$("#preview-on").click(function () {
	$("#preview-on").attr("class","btn btn-primary");
	$("#preview-off").attr("class","btn btn-default");
	$("#sticker").attr("disabled","disabled");
	$.cookie("auto","1");
	$("#preview-on").attr("class","btn btn-primar");
	$("#sticker").click();
	$("#preview-on").attr("class","btn btn-primary");
});
$("#preview-off").click(function () {
	$("#preview-off").attr("class","btn btn-primary");
	$("#preview-on").attr("class","btn btn-default");
	$("#sticker").removeAttr("disabled");
	$.cookie("auto","0");
});






var auto = $.cookie("auto");
if (auto=="1"){$("#preview-on").click();}











$("#sct").click(function () {
	$("#sctt").empty();
	$("#sctt").append('<div class="modal fade in" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" style="display: block; padding-right: 19px;">\
		<div class="modal-dialog" role="document">\
		<div class="modal-content">\
		  <div class="modal-header">\
		    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>\
		    <h4 class="modal-title" id="exampleModalLabel">状態バーの説明：</h4>\
		  </div>\
		  <div class="modal-body">\
			<div class="form-group">\
					<label for="recipient-name" class="control-label">在庫数が安全在庫より少ない場合:</label><br>\
					<span class=""></span>定量補充方式：\
					 <div style="width: 550px ;margin-bottom:5px" class="progress"><div class="progress-bar progress-bar-danger" role="progressbar" style="width: 10%;">3</div></div>\
					<span class=""></span>定期補充方式：\
					<div style="width: 550px;margin-bottom:5px" class="progress"><div class="progress-bar progress-bar-danger progress-bar-striped active" role="progressbar" style="width: 10%;">3</div></div>\
				</div>\
				 <div class="form-group">\
						<label for="recipient-name" class="control-label">在庫充分の場合:</label><br>\
						<span class=""></span>定量補充方式：\
						 <div style="width: 550px ;margin-bottom:5px" class="progress"><div class="progress-bar progress-bar-success" role="progressbar" style="width: 85%;">30</div></div>\
						<span class=""></span>定期補充方式(補充期間中)：\
						<div style="width: 550px;margin-bottom:5px" class="progress"><div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" style="width: 85%;">30</div></div>\
					 <span class=""></span>定期補充方式(補充期間外)：\
						<div style="width: 550px;margin-bottom:5px" class="progress"><div class="progress-bar progress-bar-striped active" role="progressbar" style="width: 85%;">30</div></div>\
				</div>\
				 <div class="form-group">\
						<label for="recipient-name" class="control-label">不足自動計算の場合:</label><br>\
						<span class=""></span>定量補充方式：\
						<div style="width: 550px;margin-bottom:5px" class="progress"><div class="progress-bar progress-bar-danger" role="progressbar" style="width: 10%;">3</div>\
						<div class="progress-bar progress-bar-warning" role="progressbar" style="width: 25%;">10</div></div>\
						<div style="width: 550px;margin-bottom:5px" class="progress"><div class="progress-bar progress-bar-success" role="progressbar" style="width: 25%;">10</div>\
						<div class="progress-bar progress-bar-warning" role="progressbar" style="width: 25%;">10</div></div>\
						<span class=""></span>定期補充方式：\
						　<div style="width: 550px;margin-bottom:5px" class="progress"><div class="progress-bar progress-bar-danger progress-bar-striped active" role="progressbar" style="width: 10%;">3</div>\
						<div class="progress-bar progress-bar-warning progress-bar-striped active" role="progressbar" style="width: 25%;">10</div></div>\
						<div style="width: 550px;margin-bottom:5px" class="progress"><div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" style="width: 25%;">10</div>\
						<div class="progress-bar progress-bar-warning progress-bar-striped active" role="progressbar" style="width: 25%;">10</div></div>\
				 </div>\
				 <div class="form-group">\
						<label for="recipient-name" class="control-label">発注したの場合:</label><br>\
						<span class=""></span>定量補充方式：\
						<div style="width: 550px;margin-bottom:5px" class="progress"><div class="progress-bar progress-bar-danger" role="progressbar" style="width: 10%;">3</div>\
						<div class="progress-bar progress-bar-info" role="progressbar" style="width: 25%;">10</div></div>\
						<div style="width: 550px;margin-bottom:5px" class="progress"><div class="progress-bar progress-bar-success" role="progressbar" style="width: 25%;">10</div>\
						<div class="progress-bar progress-bar-info" role="progressbar" style="width: 25%;">10</div></div>\
						<div><span class=""></span>定期補充方式：\
						　<div style="width: 550px;margin-bottom:5px" class="progress"><div class="progress-bar progress-bar-danger progress-bar-striped active" role="progressbar" style="width: 10%;">3</div>\
						<div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" style="width: 25%;">10</div></div>\
						<div style="width: 550px;margin-bottom:5px" class="progress"><div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" style="width: 25%;">10</div>\
						<div class="progress-bar progress-bar-info progress-bar-striped active" role="progressbar" style="width: 25%;">10</div></div>\
				 </div>\
			<hr>\
			 <div class="form-group">\
						<span class=""></span>※バーの長さは歴史の最高在庫数量を表示します。\
				 </div>\
		</div>\
		  <div class="modal-footer">\
		    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>\
		 </div>\
		</div>\
		</div>\
		</div></div>');})
