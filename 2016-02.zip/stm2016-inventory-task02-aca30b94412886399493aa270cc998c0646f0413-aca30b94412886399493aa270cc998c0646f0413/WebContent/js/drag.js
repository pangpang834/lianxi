var dragged;
var a;
  /* events fired on the draggable target */
  document.addEventListener("drag", function( event ) {

  }, false);

  document.addEventListener("dragstart", function( event ) {
      // store a ref. on the dragged elem
      dragged = event.target;
      var c=dragged.id;
      a=$('#'+c+'>td[name=whouse]').text();
      
      event.target.style.background="#dff0d8";
      // make it half transparent
      event.target.style.opacity = .5;
  }, false);

  document.addEventListener("dragend", function( event ) {
      // reset the transparency
	  event.target.style.background="";
      event.target.style.opacity = "";
  }, false);

  /* events fired on the drop targets */
  document.addEventListener("dragover", function( event ) {
      // prevent default to allow drop
	      event.preventDefault();
  }, false);

  document.addEventListener("dragenter", function( event ) {
      // highlight potential drop target when the draggable element enters it
      if ( event.target.className == "dropzone btn btn-default" && event.target.innerText!=a) {
          event.target.style.background = "green";}
      if ( event.target.className == "dropzone btn btn-default" && event.target.innerText==a) {
          event.target.style.background = "red";}    

  }, false);

  document.addEventListener("dragleave", function( event ) {
      // reset background of potential drop target when the draggable element leaves it
      if ( event.target.className == "dropzone btn btn-default" ) {
          event.target.style.background = "";
      }

  }, false);

  var ai=0;
  
  document.addEventListener("drop", function( event ) {
      // prevent default action (open as link for some elements)
      event.preventDefault();
      // move dragged elem to the selected drop target
      if ( event.target.className == "dropzone btn btn-default"&& event.target.innerText==a ) {
         alert("同倉庫に移動できません");
         event.target.style.background = "";
      }
      if ( event.target.className == "dropzone btn btn-default"&& event.target.innerText!=a ) {
          event.target.style.background = "";
          dragged.style.backgroundColor = "#d9edf7";
          var oldwhouse=a;
          var newwhouse=event.target.innerText
          var code=dragged.children.code.innerText;
          var detail=dragged.children.detail.innerText;
          var qty=dragged.children.num.innerText;
          var time=today();
          
          var tr = $('<tr>').appendTo('tbody#marks');
          var e=oldwhouse+"から"+newwhouse+"に移動";
          
      	tr.append('<td name="newwhouse">' + newwhouse + '</td>');
    	tr.append('<td name="whouse">' + oldwhouse + '</td>');
      	tr.append('<td name="item">' + '[' + code + ']' + detail + '</td>');
      	tr.append('<td name="date">' + time + '</td>');
      	tr.append('<td name=qty><input type="number" class="bt form-control" name="qty" value=' + qty + ' min=1 max=' + qty + ' step=1></td>');
      	tr.append('<td name=comment><input type="comment" class="tb form-control" name="com" value=' + e + '></td>');

      	var td = $('<td class="text-right">').appendTo(tr);
      	$("<a id="+ai+" onclick='haha(\""+ai+"\")' class='btn btn-xs btn-danger'>").html('<span class="glyphicon glyphicon-trash"></span> 削除').appendTo(td);
      	ai++;
//      	$('select[name="whouse"]').val("");
//      	$('select[name="item"]').val("");
//      	$('input[name="date"]').val("");
//      		$('input[name="qty"]').val(parseInt(0));
//      		$('input[name="comment"]').val("");
    
//          dragged.parentNode.removeChild( dragged );
//          event.target.appendChild( dragged );
//          alert("sou");
    
//      	if (d<=0){alert("数量が０より大きくしてください");}
//    	else if(d%1!=0){alert("整数を入力してください");}
//    	else{
      
      }
    
  }, false);
  
  
  $("#moveall").click(function(){
		var tr = $('<tr>').appendTo('tbody#fina');
		var alarmm=0;
		$("#marks tr").each(eachFunc);
//		$("#marks").empty();
		var temp = alasql('SELECT * FROM orderr ');
		
		function eachFunc(index, elem) {

			var wow=$(elem).children('td[name="newwhouse"]').text();
			var woo=$(elem).children('td[name="whouse"]').text();
			var itee=$(elem).children('td[name="item"]').text();
			var dte=$(elem).children('td[name="date"]').text();
			var qty=parseInt($(elem).children('td[name="qty"]').children('input[name="qty"]').val());

			var comm=$(elem).children('td[name="comment"]').children('input[name="com"]').val();
			var temp = alasql('SELECT * FROM orderr ');
			var iteee=itee.slice(itee.indexOf("[")+1, itee.indexOf("]"));
			

			
			
			var wo=alasql('SELECT id FROM whouse WHERE name = ?', [ woo ])[0].id;
			var ite=alasql('SELECT id FROM item WHERE code = ?', [ iteee ])[0].id;

			// stockレコード更新
			var rows = alasql('SELECT id, balance FROM stock WHERE whouse = ? AND item = ?', [ wo, ite ]);
			var stock_id, balance = 0;
			
			if (rows.length > 0) {
					balance = rows[0].balance;
			} 
	if(balance-qty>=0){
			
			if (rows.length > 0) {
				stock_id = rows[0].id;
				balance = rows[0].balance;
				alasql('UPDATE stock SET balance = ? WHERE id = ?', [ balance - qty, stock_id ]);
//				alert("入庫ができました");
			} else {
				stock_id = alasql('SELECT MAX(id) + 1 as id FROM stock')[0].id;
				alasql('INSERT INTO stock VALUES(?,?,?,?,?,?,?,?)', [ stock_id, ite, wo, balance - qty ,"1",5,5,5]);
//				alert("入庫ができました");
			}
			// transレコード追加
			var trans_id = alasql('SELECT MAX(id) + 1 as id FROM trans')[0].id;
			alasql('INSERT INTO trans VALUES(?,?,?,?,?,?)', [ trans_id, stock_id, dte, -qty, balance - qty, comm]);
			
			
			
			
			
			
			
			
			
			var wo=alasql('SELECT id FROM whouse WHERE name = ?', [ wow ])[0].id;
			var ite=alasql('SELECT id FROM item WHERE code = ?', [ iteee ])[0].id;
			// stockレコード更新
			var rows = alasql('SELECT id, balance FROM stock WHERE whouse = ? AND item = ?', [ wo, ite ]);
			var stock_id, balance = 0;
			
			
			
			if (rows.length > 0) {
				stock_id = rows[0].id;
				balance = rows[0].balance;
				alasql('UPDATE stock SET balance = ? WHERE id = ?', [ balance + qty, stock_id ]);
//				alert("入庫ができました");
			} else {
				stock_id = alasql('SELECT MAX(id) + 1 as id FROM stock')[0].id;
				alasql('INSERT INTO stock VALUES(?,?,?,?,?,?,?,?)', [ stock_id, ite, wo, balance + qty ,"1",5,5,5]);
//				alert("入庫ができました");
			}
			// transレコード追加
			var trans_id = alasql('SELECT MAX(id) + 1 as id FROM trans')[0].id;
			alasql('INSERT INTO trans VALUES(?,?,?,?,?,?)', [ trans_id, stock_id, dte, qty, balance + qty, comm]);
			// リロード
			
			stock_id=stock_id-1;
			var tm=$.cookie(stock_id.toString());
			if (tm>qty){$.cookie(stock_id.toString(),tm-qty);}
			else{
			$.cookie(stock_id.toString(),null);}
	
				
			$(elem).remove();
		}else{  $(elem).css("background-color","#f2dede");alarmm=1;   }
	
	}//func
		
		stocks = alasql(sql, [ q3 + '%' ]);
		var stock = stocks[i];
		
		$('#tbody-stocks').empty();

		var tbody = $('#tbody-stocks');
		var idd=0;

		for (var i = 0; i < stocks.length; i++) {
			var id=i+1;
			var stock = stocks[i];
			if (stock.stock.balance>0){
			var tr = $('<tr id="sbb'+idd+'" draggable="true"></tr>');
			tr.append('<td name="whouse" data-href="stock.html?id=' + stock.stock.id + '" id="ws'+idd+'">' + stock.whouse.name + '</td>');
			tr.append('<td name="kind" data-href="stock.html?id=' + stock.stock.id + '">' + stock.kind.text + '</td>');
			tr.append('<td name="code" data-href="stock.html?id=' + stock.stock.id + '" id="ite'+idd+'">' + stock.item.code + '</td>');
			tr.append('<td name="maker" data-href="stock.html?id=' + stock.stock.id + '" id="maker'+idd+'">' + stock.item.maker + '</td>');
			tr.append('<td name="detail" data-href="stock.html?id=' + stock.stock.id + '" id="detail'+idd+'">' + stock.item.detail + '</td>');
			tr.append('<td name="money" data-href="stock.html?id=' + stock.stock.id + '" style="text-align: right;">' + numberWithCommas(stock.item.price) + '</td>');
			tr.append('<td name="num" data-href="stock.html?id=' + stock.stock.id + '" style="text-align: right;">' + stock.stock.balance + '</td>');
			tr.append('<td data-href="stock.html?id=' + stock.stock.id + '" id="short'+idd+'">' + stock.item.unit + '</td>');
			
			tr.appendTo(tbody);
			idd++;
			}
		}
		
		
		
		
		
		// リロード
		if(alarmm==0){alert("在庫移動ができました");}
		else{alert("移動できない品物があります");}
//		window.location.assign('in.html');
	})
  
	
	
	
	
	
  function haha(ss){
		$("#"+ss+"").parents("tr").remove();
	}
  
  
var stocks;
//d();
//
//draw();

// 検索ボックス作成
//function d(){
var ss=alasql('SELECT * FROM stock;');
var rows = alasql('SELECT * FROM whouse;');
for (var i = 0; i < rows.length; i++) {
	var row = rows[i];
	var option = $('<option>');
	option.attr('value', row.whouse.id);
	option.text(row.whouse.name);
	$('select[name="q1"]').append(option);
}

var rows = alasql('SELECT * FROM kind;');
for (var i = 0; i < rows.length; i++) {
	var row = rows[i];
	var option = $('<option>');
	option.attr('value', row.kind.id);
	option.text(row.kind.text);
	$('select[name="q2"]').append(option);
}

// 検索条件の取得
var q1 = parseInt($.url().param('q1') || '0');
$('select[name="q1"]').val(q1);
var q2 = parseInt($.url().param('q2') || '0');
$('select[name="q2"]').val(q2);
var q3 = $.url().param('q3') || '';
$('input[name="q3"]').val(q3);

// SQLの生成
var sql = 'SELECT * \
	FROM stock \
	JOIN whouse ON whouse.id = stock.whouse \
	JOIN item ON item.id = stock.item \
	JOIN kind ON kind.id = item.kind \
	WHERE item.code LIKE ? ';

sql += q1 ? 'AND whouse.id = ' + q1 + ' ' : '';
sql += q2 ? 'AND kind.id = ' + q2 + ' ' : '';

// SQL実行
stocks = alasql(sql, [ q3 + '%' ]);

//};

function pr2(a){
	return a*100;
};
// HTML作成
//function draw(){

var res = alasql('SELECT stock,SUM(qty) AS qty FROM trans WHERE qty < 0 GROUP BY stock ');
dif=90;

var tbody = $('#tbody-stocks');
var idd=0;

for (var i = 0; i < stocks.length; i++) {
	var id=i+1;
	var tm = parseInt($.cookie(i.toString()));

	var smax=alasql("Select MAX(balance) AS a FROM trans WHERE stock=?", [ id ])[0].a;	
	var at=alasql("Select balance AS a FROM stock WHERE id=?", [ id ])[0].a;	
	if(tm+at>smax){smax=tm+at;$.cookie("max"+id.toString()),tm+at;}
	
	
	var stock = stocks[i];
	if (stock.stock.balance>0){
	var tr = $('<tr id="sbb'+idd+'" draggable="true"></tr>');
	tr.append('<td name="whouse" data-href="stock.html?id=' + stock.stock.id + '" id="ws'+idd+'">' + stock.whouse.name + '</td>');
	tr.append('<td name="kind" data-href="stock.html?id=' + stock.stock.id + '">' + stock.kind.text + '</td>');
	tr.append('<td name="code" data-href="stock.html?id=' + stock.stock.id + '" id="ite'+idd+'">' + stock.item.code + '</td>');
	tr.append('<td name="maker" data-href="stock.html?id=' + stock.stock.id + '" id="maker'+idd+'">' + stock.item.maker + '</td>');
	tr.append('<td name="detail" data-href="stock.html?id=' + stock.stock.id + '" id="detail'+idd+'">' + stock.item.detail + '</td>');
	tr.append('<td name="money" data-href="stock.html?id=' + stock.stock.id + '" style="text-align: right;">' + numberWithCommas(stock.item.price) + '</td>');
	tr.append('<td name="num" data-href="stock.html?id=' + stock.stock.id + '" style="text-align: right;">' + stock.stock.balance + '</td>');
	tr.append('<td data-href="stock.html?id=' + stock.stock.id + '" id="short'+idd+'">' + stock.item.unit + '</td>');
	
	tr.appendTo(tbody);
	idd++;
	}
}




//get today
function today(){
var day = new Date();
	    if ( day.getYear() >= 2000 ){ var year = day.getYear() }
	    else {  var year = day.getYear() +1900 }
	    var month = day.getMonth()+1;
	    var date = day.getDate();
	        if (month < 10) {    //月.日が一桁の時頭に0を付ける処理
	            month = "0" + month;	                         }
	        if (date < 10) {
	            date = "0" + date;	                        }
	        var time=year+'-'+month+'-'+date;
	        return time;
}

// クリック動作

//$('tbody > tr > td').on('click', function() {
//	window.location = $(this).attr('data-href');
//});

var s=alasql('SELECT * FROM orderr ');	


