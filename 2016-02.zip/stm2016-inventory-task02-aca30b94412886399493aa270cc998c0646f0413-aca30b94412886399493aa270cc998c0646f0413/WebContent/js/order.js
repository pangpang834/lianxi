//
//var orders = alasql('SELECT * FROM orderr ');
//var tbody = $('#marks');
//for (var i = 0; i < orders.length; i++) {
//	var order = orders[i];
//	if (order.arr=="w"){var arr="<span class='label label-primary'>待ち</span>";var tr = $('<tr style="background-color:#d9edf7;">').appendTo(tbody);}
//	else{var arr="<span class='label label-success'>到着</span>";var tr = $('<tr style="background-color:#dff0d8;">').appendTo(tbody);}
////	var tr = $('<tr '+l+'>').appendTo(tbody);
//		var book = {
//			whouse: order.whouse,
//			item: order.item,
//			date: order.date,
//			qty: order.qty,
//			};
//	var mes =JSON.stringify(book);
//		
//	
//	tr.append('<td>' + order.whouse + '</td>');
//	tr.append('<td>' + order.item + '</td>');
//	tr.append('<td>' + order.date + '</td>');
//	tr.append('<td>' + order.qty + '</td>');
//	tr.append('<td>' + mes + '</td>');
//	tr.append('<td>' + arr + '</td>');
//	
//	tr.append('<td><div id="placeHolderr'+i+'"></div></td>');
//	
//	
//	var typeNumber = 5;
//	var errorCorrectionLevel = 'L';
//	var qr = qrcode(typeNumber, errorCorrectionLevel);
//	qr.addData(mes);
//	qr.make();
//	document.getElementById('placeHolderr'+i+'').innerHTML = qr.createImgTag();
//
//}
var orders = alasql('SELECT * FROM orderr ');


var orders = alasql('SELECT * FROM orderr WHERE arr="w"');
var tbody = $('#marks');
for (var j = 0; j < orders.length; j++) {
	var order = orders[j];
	if (order.orderr.arr=="w"){var arr="<span class='label label-primary'>待ち</span>";var tr = $('<tr style="background-color:#d9edf7;">').appendTo(tbody);}
	else{var arr="<span class='label label-success'>到着</span>";var tr = $('<tr style="background-color:#dff0d8;">').appendTo(tbody);}
//	var tr = $('<tr '+l+'>').appendTo(tbody);
		var book = {
			whouse: order.orderr.whouse,
			item: order.orderr.item,
			date: order.orderr.date,
			qty: order.orderr.qty,
			};
	var mes =JSON.stringify(book);
		
	
	tr.append('<td>' + order.orderr.whouse + '</td>');
	tr.append('<td>' + order.orderr.item + '</td>');
	tr.append('<td>' + order.orderr.date + '</td>');
	tr.append('<td>' + order.orderr.qty + '</td>');
	tr.append('<td>' + mes + '</td>');
	tr.append('<td>' + arr + '</td>');
	
	tr.append('<td><div id="placeHolderr'+j+'"></div></td>');
	
	
	var typeNumber = 5;
	var errorCorrectionLevel = 'L';
	var qr = qrcode(typeNumber, errorCorrectionLevel);
	qr.addData(mes);
	qr.make();
	document.getElementById('placeHolderr'+j+'').innerHTML = qr.createImgTag();

}







var orders = alasql('SELECT * FROM orderr WHERE arr="a"');
var tbody = $('#marks');
for (var i = 0; i < orders.length; i++) {
	var order = orders[i];
	if (order.orderr.arr=="w"){var arr="<span class='label label-primary'>待ち</span>";var tr = $('<tr style="background-color:#d9edf7;">').appendTo(tbody);}
	else{var arr="<span class='label label-success'>到着</span>";var tr = $('<tr style="background-color:#dff0d8;">').appendTo(tbody);}
//	var tr = $('<tr '+l+'>').appendTo(tbody);
		var book = {
			whouse: order.orderr.whouse,
			item: order.orderr.item,
			date: order.orderr.date,
			qty: order.orderr.qty,
			};
	var mes =JSON.stringify(book);
		
	
	tr.append('<td>' + order.orderr.whouse + '</td>');
	tr.append('<td>' + order.orderr.item + '</td>');
	tr.append('<td>' + order.orderr.date + '</td>');
	tr.append('<td>' + order.orderr.qty + '</td>');
	tr.append('<td>' + mes + '</td>');
	tr.append('<td>' + arr + '</td>');
	
	tr.append('<td><div id="placeHolderr'+(i+j)+'"></div></td>');
	
	
	var typeNumber = 5;
	var errorCorrectionLevel = 'L';
	var qr = qrcode(typeNumber, errorCorrectionLevel);
	qr.addData(mes);
	qr.make();
	document.getElementById('placeHolderr'+(i+j)+'').innerHTML = qr.createImgTag();

}





