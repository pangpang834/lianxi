$("#erasable").hide();
var syyy=0;
var stor=[];
var orders = alasql('SELECT * FROM orderr ');
var woo;
var sb=[];

var te=alasql('SELECT * FROM orderr WHERE arr="w" ');

for (var i = 0; i < te.length; i++) {
	stor[i]=i;
}
//入庫ボタン
$("#addall").click(function(){
	var tr = $('<tr>').appendTo('tbody#fina');
	$("#marks tr").each(eachFunc);
	$("#marks").empty();
	var temp = alasql('SELECT * FROM orderr ');
	
	function eachFunc(index, elem) {
//		$(elem).text(index+"番目の要素");
		var woo=$(elem).children('td[name="whouse"]').text();
		var itee=$(elem).children('td[name="item"]').text();
		var dte=$(elem).children('td[name="date"]').text();
		var qty=parseInt($(elem).children('td[name="qty"]').text());
		var comm=$(elem).children('td[name="comment"]').text();
		
		var temp = alasql('SELECT * FROM orderr ');
		
		if(comm=="発注品"){
			var book = {
					whouse: woo,
					item: itee,
					date: dte,
					qty: qty,
					
							};
			var js = JSON.stringify(book);
			var idd=-1;
			for(var i=0;i<sb.length;i++){
				var bs=$("#amm"+i+"").text();
				var arr="待ち";
				if(sb[i][1]==js&&bs==arr){idd=sb[i][0];break;}
			}
			$("#amm"+idd+"").remove();
			$("#am"+idd+"").after("<td><span class='label label-success'>到着</span></td>");
			var tempp = alasql('SELECT * FROM orderr ');
			
			var temp1=alasql('SELECT * FROM orderr WHERE whouse=? AND item=? AND qty=? AND date=? AND arr="w" ', [ woo, itee,qty,dte ]);
			alasql('DELETE FROM orderr WHERE whouse=? AND item=? AND qty=? AND date=? AND arr="w" ', [ woo, itee,qty,dte ]);
			
			for(var i=0;i<temp1.length;i++){
				if(i==0){   alasql('INSERT INTO orderr VALUES(?,?,?,?,?);', [woo, itee,qty,dte,"a"]);	                    }
				else{     alasql('INSERT INTO orderr VALUES(?,?,?,?,?);', [woo, itee,qty,dte,"w"]);	                          }
				
				
			}
			
//			alasql('UPDATE orderr SET arr = "a" WHERE whouse=? AND item=? AND qty=? AND date=? ', [ woo, itee,qty,dte ]);
			var temp1=alasql('SELECT * FROM orderr WHERE whouse=? AND item=? AND qty=? AND date=? ', [ woo, itee,qty,dte ]);
		
			
			
			
			
			
			
			
			
			
		}
		
		
		
		
		
		
		var iteee=itee.slice(itee.indexOf("[")+1, itee.indexOf("]"));
		
		var wo=alasql('SELECT id FROM whouse WHERE name = ?', [ woo ])[0].id;
		var ite=alasql('SELECT id FROM item WHERE code = ?', [ iteee ])[0].id;


		// stockレコード更新
		var rows = alasql('SELECT id, balance FROM stock WHERE whouse = ? AND item = ?', [ wo, ite ]);
		var stock_id, balance = 0;
		if (rows.length > 0) {
			stock_id = rows[0].id;
			balance = rows[0].balance;
			alasql('UPDATE stock SET balance = ? WHERE id = ?', [ balance + qty, stock_id ]);
//			alert("入庫ができました");
		} else {
			stock_id = alasql('SELECT MAX(id) + 1 as id FROM stock')[0].id;
			alasql('INSERT INTO stock VALUES(?,?,?,?,?,?,?,?)', [ stock_id, ite, wo, balance + qty ,"1",5,5,5]);
//			alert("入庫ができました");
		}
		// transレコード追加
		var trans_id = alasql('SELECT MAX(id) + 1 as id FROM trans')[0].id;
		alasql('INSERT INTO trans VALUES(?,?,?,?,?,?)', [ trans_id, stock_id, dte, qty, balance + qty, comm]);
		// リロード

		var book = {
				whouse: wo,
				item: ite,
				date: dte,
				qty: qty,
				comment: comm,
				};
		var jsonText = JSON.stringify(book);
		
		
//		tr.append("<input value="+jsonText+"><br>");
		tr.append("<div class='input-group'><input type='text' style='width: 700px' class='form-control' value="+jsonText+" aria-describedby='basic-addon1'></div><br>");
		
		stock_id=stock_id-1;
		var tm=$.cookie(stock_id.toString());
		if (tm>qty){$.cookie(stock_id.toString(),tm-qty);}
		else{
		$.cookie(stock_id.toString(),null);}
		
	}
	// リロード
	alert("入庫ができました");
//	window.location.assign('in.html');
})
//通信ボタン
$("#camp").click(function(){
	var js=$("#text").val();
	var to=JSON.parse(js);
	
	var ai = "addb"+syyy;
	syyy++;
	
	var idd=-1;
	for(var i=0;i<sb.length;i++){
		var bs=$("#ma"+i+"").css("background-color");
	
		if(sb[i][1]==js&&bs=="rgb(217, 237, 247)"){idd=sb[i][0];break;}
	}
	var co=(idd>=0)?"発注品":to.comment;
	if(idd>=0){
//		var s="#ma"+idd+"";
		$("#ma"+idd+"").css("background-color","#dff0d8");
	}

	function isBigEnough(element, index, array) {
		  return (element != idd);
		}
	var storss = stor.filter(isBigEnough);
	stor=storss;
	
	
	var tr = $('<tr>').appendTo('tbody#marks');
	tr.append('<td name="whouse">' + to.whouse + '</td>');
	tr.append('<td name="item">' +to.item+ '</td>');
	tr.append('<td name="date">' + to.date + '</td>');
	tr.append('<td name=qty>' + to.qty + '</td>');
	tr.append('<td name=comment>' + co + '</td>');
	var td = $('<td class="text-right">').appendTo(tr);
//	$('<a onclick="this.parents("tr").remove();" class="btn btn-xs btn-danger">').html('<span class="glyphicon glyphicon-trash"></span> 削除').appendTo(td);
	$("<a id="+ai+" onclick='haha(\""+ai+"\")' name="+idd.toString()+" class='btn btn-xs btn-danger'>").html('<span class="glyphicon glyphicon-trash"></span> 削除').appendTo(td);
	if(idd>=0){   $("#omain").click();
		
	}else{	$("#reflash").click();}
	
})

//スキャンボタン
$("#scan").click(function(){
	$("#camp").click();
	
})

//更新ボタン
$("#reflash").click(function(){
　　　//	make data
	var ss =  ["sp埼玉","sp青森","sp福島","sp仙台","sp四国","sp神奈川","sp熊本"];
	var com = ss[selectFrom(0, ss.length-1)];
	function selectFrom(lowerValue, upperValue) {
		var choices = upperValue - lowerValue + 1;
		return Math.floor(Math.random() * choices + lowerValue);
		}
	var wh = selectFrom(1,4);
	var it = selectFrom(1,18);
	var nu = selectFrom(1,100);
	var time=today();	
　　　//	
	var aa=alasql('SELECT name FROM whouse WHERE id = ?', [ wh ]);
	var bb=alasql('SELECT code,detail FROM item WHERE id = ?', [ it ]);
	var cc='[' + bb[0].code + ']' + bb[0].detail ;
	var book = {
			whouse: aa[0].name,
			item: cc,
			date: time,
			
			qty: nu,
			comment: com,
			};
	var jsonText = JSON.stringify(book);
　　　//	make qrcode
	var typeNumber = 5;
	var errorCorrectionLevel = 'L';
	var qr = qrcode(typeNumber, errorCorrectionLevel);
	qr.addData(jsonText);
	qr.make();
	document.getElementById('placeHolder').innerHTML = qr.createImgTag();
　　　//	make json
	$("#text").val(jsonText);
	
})
//発注から作成ボタン作成
var orders = alasql('SELECT * FROM orderr ');
//for (var i = 0; i < orders.length; i++) {
//	var order = orders[i];
//	var rr=i.toString();
//	$('#addlist').append("<li><a onclick='clicktype(\""+rr+"\")'>"+order[0]+order[1]+"</a></li>");
//}

$("#omain").click(function(){
	if (stor.length==0){$("#reflash").click();}
	else{
	var i = stor[selectFrom(0, stor.length-1)];
	
//	var i = selectFrom(0,orders.length-1);
//	if(stor.includes(i)){$("#omain").click( );  }
	var rr=i.toString();
	clicktype2(rr);
}});

function clicktype2(rr) {
	var s=parseInt(rr);
	var order = te[s];
	var book = {
			whouse: order.orderr.whouse,
			item: order.orderr.item,
			date: order.orderr.date,
			qty: order.orderr.qty,
			};
	
	var mes =JSON.stringify(book);
	$("#text").val(mes);
	var typeNumber = 5;
	var errorCorrectionLevel = 'L';
	var qr = qrcode(typeNumber, errorCorrectionLevel);
	qr.addData(mes);
	qr.make();
	document.getElementById('placeHolder').innerHTML = qr.createImgTag();
}	







//l1='background-color:#d9edf7;';
//l2='background-color:#dff0d8;';

var orders = alasql('SELECT * FROM orderr ');
var tbody = $('#markss');
var sb=[];
for (var i = 0; i < te.length; i++) {
	var order = te[i];
	if (order.orderr.arr=="w"){var arr="<span class='label label-primary'>待ち</span>";var tr = $('<tr id="ma'+i+'" style="background-color:#d9edf7;">').appendTo(tbody);
//	}
//	else{var arr="<span class='label label-success'>到着</span>";var tr = $('<tr style="background-color:#dff0d8;">').appendTo(tbody);}

	var book = {
			whouse: order.orderr.whouse,
			item: order.orderr.item,
			date: order.orderr.date,
			qty: order.orderr.qty,
			};
	var mes =JSON.stringify(book);
		
		
	tr.append('<td>' + order.orderr.whouse + '</td>');
	tr.append('<td>' + order.orderr.item + '</td>');
	tr.append('<td>' + order.orderr.date + '</td>');
	tr.append('<td>' + order.orderr.qty + '</td>');
	tr.append('<td id="am'+i+'">' + mes + '</td>');
	tr.append('<td id="amm'+i+'">' + arr + '</td>');
	
	tr.append('<td><div id="placeHolderr'+i+'"></div></td>');
	
	
	var typeNumber = 5;
	var errorCorrectionLevel = 'L';
	var qr = qrcode(typeNumber, errorCorrectionLevel);
	qr.addData(mes);
	qr.make();
	document.getElementById('placeHolderr'+i+'').innerHTML = qr.createImgTag();
	sb.push([i,mes]);
}	
	
}

var btn = document.getElementById("reflash");
//创建事件对象
var event = document.createEvent("MouseEvents");
//初始化事件对象
event.initMouseEvent("click", true, true, document.defaultView, 0, 0, 0, 0, 0,
false, false, false, false, 0, null);
//触发事件
btn.dispatchEvent(event);



//get today
function today(){
var day = new Date();
	    if ( day.getYear() >= 2000 ){ var year = day.getYear() }
	    else {  var year = day.getYear() +1900 }
	    var month = day.getMonth()+1;
	    var date = day.getDate();
	        if (month < 10) {    //月.日が一桁の時頭に0を付ける処理
	            month = "0" + month;	                         }
	        if (date < 10) {
	            date = "0" + date;	                        }
	        var time=year+'-'+month+'-'+date;
	        return time;
}
//倉庫情報読み込み

function fresh1(){
	var rows = alasql('SELECT * FROM whouse;');
	for (var i = 0; i < rows.length; i++) {
	var row = rows[i];
	var option = $('<option>');
	option.attr('value', row.whouse.id);
	option.text(row.whouse.name);
	$('select[name="whouse"]').append(option);
}}
//　商品情報読み込み

function fresh2(){
	var rows = alasql('SELECT * FROM item;');
for (var i = 0; i < rows.length; i++) {
	var row = rows[i];
	var option = $('<option>');
	option.attr('value', row.item.id);
	option.text('[' + row.item.code + '] ' + row.item.detail);
	$('select[name="item"]').append(option);
}}
fresh1();
fresh2();
$("#omain").click();
//手入力ボタン
$("#hand").click(function(){
	var text2=$("#hand").text();	
	if (text2=="手入力"){
		text2="手入力収納";		
		$("#erasable").slideDown(500);	}	
	else if(text2=="手入力収納"){
		text2="手入力";
		$("#erasable").slideUp(500);	}
	else{}
	$("#hand").text(text2);
})

//削除ボタン

function haha(ss){
	var name=$("#"+ss+"").attr("name");
	var idd=parseInt(name);
	if(idd>=0){
		$("#ma"+idd+"").css("background-color","#d9edf7");
	}
	stor.push(idd);
	
	$("#"+ss+"").parents("tr").remove();
}



//追加ボタン
$("#add").click(function(){
	
	var ai = "addb"+syyy;
	syyy++;
	
	var a=parseInt($('select[name="whouse"]').val());
	var b=parseInt($('select[name="item"]').val());
	var c=$('input[name="date"]').val();
	var d=$('input[name="qty"]').val();
	if (d<=0){alert("数量が０より大きくしてください");}
	else if(d%1!=0){alert("整数を入力してください");}
	else{
	var e=$('input[name="comment"]').val();
	var aa=alasql('SELECT name FROM whouse WHERE id = ?', [ a ]);
	var bb=alasql('SELECT code,detail FROM item WHERE id = ?', [ b ]);
	
	var cc='[' + bb[0].code + ']' + bb[0].detail ;
	if(e=="発注品"){                                    
		var book = {
				whouse: aa[0].name,
				item: cc,
				date: c,
				qty: parseInt(d),
//				comment: e,
				};
		
		var mes =JSON.stringify(book);
		$("#text").val(mes);
		$("#camp").click();
	}
	else{
//	var rows = alasql('SELECT id, balance FROM stock WHERE whouse = ? AND item = ?', [ a, bb ]);
	
	
//	var tr = $('<tr>').appendTo('#tbody-addr');
	var tr = $('<tr>').appendTo('tbody#marks');
	tr.append('<td name="whouse">' + aa[0].name + '</td>');
	tr.append('<td name="item">' + '[' + bb[0].code + ']' + bb[0].detail + '</td>');
	tr.append('<td name="date">' + c + '</td>');
	tr.append('<td name=qty>' + d + '</td>');
	tr.append('<td name=comment>' + e + '</td>');
	var td = $('<td class="text-right">').appendTo(tr);
//	$('<a  class="btn btn-xs btn-danger">').html('<span onclick="unadd();" class="glyphicon glyphicon-trash"></span> 削除').appendTo(td);
	$("<a id="+ai+" onclick='haha(\""+ai+"\")' class='btn btn-xs btn-danger'>").html('<span class="glyphicon glyphicon-trash"></span> 削除').appendTo(td);
	
	$('select[name="whouse"]').val("");
	$('select[name="item"]').val("");
	$('input[name="date"]').val("");
		$('input[name="qty"]').val(parseInt(0));
		$('input[name="comment"]').val("");
			
}}})
	