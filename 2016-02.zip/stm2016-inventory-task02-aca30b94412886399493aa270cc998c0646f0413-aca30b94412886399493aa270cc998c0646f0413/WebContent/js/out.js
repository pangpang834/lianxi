$("#erasable").hide();
var syyy=0;











 
//(function() {
//	  var httpRequest;
//	  document.getElementById("ajaxButton").onclick = function() { makeRequest('http://getbootstrap.com/javascript/'); };
//	
//	  function makeRequest(url) {
//	    httpRequest = new XMLHttpRequest();
//	
//	    if (!httpRequest) {
//	      alert('Giving up :( Cannot create an XMLHTTP instance');
//	      return false;
//	    }
//	    httpRequest.onreadystatechange = alertContents;
//	    httpRequest.open('GET', url);
//	    httpRequest.send();
//	  }
//	  
//	  function alertContents() {
//	    if (httpRequest.readyState === XMLHttpRequest.DONE) {
//	      if (httpRequest.status === 200) {
//	        alert(httpRequest.responseText);
//	      } else {
//	        alert('There was a problem with the request.');
//	      }
//	    }
//	  }
//})();




















//var event = {
//	clientList: [],
//	listen: function( key, fn ){
//		if ( !this.clientList[ key ] ){
//		this.clientList[ key ] = [];
//		}
//		this.clientList[ key ].push( fn ); // 订阅的消息添加进缓存列表
//		},
//	trigger: function(){
//		var key = Array.prototype.shift.call( arguments ), // (1);
//		fns = this.clientList[ key ];
//		if ( !fns || fns.length === 0 ){ // 如果没有绑定对应的消息
//		return false;
//		}
//		for( var i = 0, fn; fn = fns[ i++ ]; ){
//		fn.apply( this, arguments ); // (2) // arguments 是trigger 时带上的参数
//}
//}
//};
//var installEvent = function( obj ){
//	for ( var i in event ){
//		obj	[ i ] = event[ i ];
//	}
//};
//var salesOffices = {};
//installEvent( salesOffices );
//
//salesOffices.listen( 'squareMeter88', function( price ){ // 小明订阅消息
//	console.log( '价格= ' + price );
//});
//salesOffices.listen( 'squareMeter100', function( price ){ // 小红订阅消息
//	console.log( '价格= ' + price );
//});
//salesOffices.trigger( 'squareMeter88', 2000000 ); // 输出：2000000
//salesOffices.trigger( 'squareMeter100', 3000000 ); // 输出：3000000






















//
//var salesOffices = {}; // 定义售楼处
//salesOffices.clientList = {}; // 缓存列表，存放订阅者的回调函数
//salesOffices.listen = function( key, fn ){
//if ( !this.clientList[ key ] ){ // 如果还没有订阅过此类消息，给该类消息创建一个缓存列表
//this.clientList[ key ] = [];
//}
//this.clientList[ key ].push( fn ); // 订阅的消息添加进消息缓存列表
//};
//salesOffices.trigger = function(){ // 发布消息
//var key = Array.prototype.shift.call( arguments ), // 取出消息类型
//fns = this.clientList[ key ]; // 取出该消息对应的回调函数集合
//if ( !fns || fns.length === 0 ){ // 如果没有订阅该消息，则返回
//return false;
//}
//for( var i = 0, fn; fn = fns[ i++ ]; ){
//fn.apply( this, arguments ); // (2) // arguments 是发布消息时附送的参数
//}
//};
//salesOffices.listen( 'squareMeter88', function( price ){ // 小明订阅88 平方米房子的消息
//console.log( '价格= ' + price ); // 输出： 2000000
//});
//salesOffices.listen( 'squareMeter110', function( price ){ // 小红订阅110 平方米房子的消息
//console.log( '价格= ' + price ); // 输出： 3000000
//});
//salesOffices.trigger( 'squareMeter88', 2000000 ); // 发布88 平方米房子的价格
//salesOffices.trigger( 'squareMeter110', 3000000 ); // 发布110 平方米房子的价格



















//var mult = function(){
//	console.log( '开始计算乘积' );
//	var a = 1;
//	for ( var i = 0, l = arguments.length; i < l; i++ ){
//	a = a * arguments[i];
//	}
//	return a;
//	};
//
//var proxyMult = (function(){
//	var cache = {};
//	return function(){
//	var args = Array.prototype.join.call( arguments, ',' );
//	if ( args in cache ){
//	return cache[ args ];
//	}
//	return cache[ args ] = mult.apply( this, arguments );
//	}
//	})();
//	proxyMult( 1, 2, 3, 4 ); // 输出：24
//	proxyMult( 1, 2, 3, 4 ); // 输出：24

	




//Function.prototype.before = function( beforefn ){
//	var __self = this; // 保存原函数的引用
//	return function(){ // 返回包含了原函数和新函数的"代理"函数
//		beforefn.apply( this, arguments ); // 执行新函数，修正this
//		return __self.apply( this, arguments ); // 执行原函数
//	}
//};
//
//Function.prototype.after = function( afterfn ){
//	var __self = this;
//	return function(){
//		var ret = __self.apply( this, arguments );
//		afterfn.apply( this, arguments );
//		return ret;
//	}
//};
//
//var func = function(){
//	console.log( 2 );
//};
//
//func = func.before(function(){
//	console.log( 1 );
//}).after(function(){
//	console.log( 3 );
//});
//
//func();
//
//
//
//var cost = (function(){
//	var args = [];
//	
//	return function(){
//		if ( arguments.length === 0 ){
//			var money = 0;
//			for ( var i = 0, l = args.length; i < l; i++ ){
//			money += args[ i ];
//			}
//			return money;
//		}else{
//			[].push.apply( args, arguments );
//		}
//	}
//})();
//cost( 100 ); // 未真正求值
//cost( 200 ); // 未真正求值
//cost( 300 ); // 未真正求值
//console.log( cost() ); // 求值并输出：600
//
//
//
//var currying = function( fn ){
//	var args = [];
//	return function(){
//		if ( arguments.length === 0 ){
//			return fn.apply( this, args );
//		}else{
//			[].push.apply( args, arguments );
//			return arguments.callee;
//		}
//	}
//};
//
//var cost = (function(){
//	var money = 0;
//	return function(){
//		for ( var i = 0, l = arguments.length; i < l; i++ ){
//			money += arguments[ i ];
//		}
//		return money;
//	}
//})();
//
//var cost = currying( cost ); // 转化成currying 函数
//cost( 100 ); // 未真正求值
//cost( 200 ); // 未真正求值
//cost( 300 ); // 未真正求值
//alert ( cost() ); // 求值并输出：600
//
//
//







var obj = document.getElementById("main");
var items = [ "click", "keypress" ];
//遍历items中的每一项
//for ( var i = 0; i < items.length; i++ ) {
////用自执行的匿名函数来激发作用域
//	(function(){
//		//在些作用域内存储值
//		var item = items[i];
//		//为obj元素绑定函数
//		obj[ "on" + item ] = function() {
//		//item引用一个父级的变量，
//		//该变量在此for循环的上文中已被成功地scoped(?)
//		alert( "Thanks for your " + item );		};
//	})();
//
//}


//
//for ( var i = 0; i < items.length; i++ ) {
////用自执行的匿名函数来激发作用域
////(function(){
//	//在些作用域内存储值
////	var item = items[i];
//	//为obj元素绑定函数
//	obj[ "on" + items[i] ] = function() {
//	//item引用一个父级的变量，
//	//该变量在此for循环的上文中已被成功地scoped(?)
//	alert( "Thanks for your " + items[i] );		};
////})();
//
//}









//追加ボタン
$("#add").click(function(){
	var a=parseInt($('select[name="whouse"]').val());
	var b=parseInt($('select[name="item"]').val());
	var c=$('input[name="date"]').val();
	var d=parseInt($('input[name="qty"]').val());
	
	var rows = alasql('SELECT id, balance FROM stock WHERE whouse = ? AND item = ?', [ a, b ]);
	var stock_id, balance = 0;
	if (rows.length > 0) {
		balance = rows[0].balance;	}
	if (rows.length <=0){alert("在庫なし");} 
	else if((d-rows[0].balance)>0){
		alert("在庫（"+rows[0].balance+"）不足");
	}
	else{	
	if (d<=0){alert("数量が０より大きくしてください");}
	else if(d%1!=0){alert("整数を入力してください");}
	else{
	var e=$('input[name="comment"]').val();
//	var rows = alasql('SELECT id, balance FROM stock WHERE whouse = ? AND item = ?', [ a, bb ]);
	var aa=alasql('SELECT name FROM whouse WHERE id = ?', [ a ]);
	var bb=alasql('SELECT code,detail FROM item WHERE id = ?', [ b ]);
	
	var ai = "addb"+syyy;
	syyy++;
	
//	var tr = $('<tr>').appendTo('#tbody-addr');
	var tr = $('<tr>').appendTo('tbody#marks');
	tr.append('<td name="whouse">' + aa[0].name + '</td>');
	tr.append('<td name="item">' + '[' + bb[0].code + ']' + bb[0].detail + '</td>');
	tr.append('<td name="date">' + c + '</td>');
	tr.append('<td name="qty">' + d + '</td>');
//	tr.append('<td id="bababa">' + balance + '</td>');
	tr.append('<td name="comment">' + e + '</td>');

	var td = $('<td class="text-right">').appendTo(tr);
	$("<a id="+ai+" onclick='haha(\""+ai+"\")' class='btn btn-xs btn-danger'>").html('<span class="glyphicon glyphicon-trash"></span> 削除').appendTo(td);
	
	$('select[name="whouse"]').val("");
	$('select[name="item"]').val("");
	$('input[name="date"]').val("");
		$('input[name="qty"]').val(parseInt(0));
		$('input[name="comment"]').val("");
}}})
	



//入庫ボタン
$("#addall").click(function(){
	var tr = $('<tr>').appendTo('tbody#finaa');
	var alarmm=0;
	
	$("#marks tr").each(eachFunc);
	function eachFunc(index, elem) {
//		$(elem).text(index+"番目の要素");
		var woo=$(elem).children('td[name="whouse"]').text();
		var itee=$(elem).children('td[name="item"]').text();
		var dte=$(elem).children('td[name="date"]').text();
		var qty=parseInt($(elem).children('td[name="qty"]').text());
		var comm=$(elem).children('td[name="comment"]').text();
		
		
		var iteee=itee.slice(itee.indexOf("[")+1, itee.indexOf("]"));
		
		var wo=alasql('SELECT id FROM whouse WHERE name = ?', [ woo ])[0].id;
		var ite=alasql('SELECT id FROM item WHERE code = ?', [ iteee ])[0].id;

		// stockレコード更新
		var rows = alasql('SELECT id, balance FROM stock WHERE whouse = ? AND item = ?', [ wo, ite ]);
		var stock_id, balance = 0;
		if (rows.length > 0) {
			stock_id = rows[0].id;
			balance = rows[0].balance;
					
		}
	if(balance-qty>=0){

		if (rows.length > 0) {
			stock_id = rows[0].id;
			balance = rows[0].balance;
			alasql('UPDATE stock SET balance = ? WHERE id = ?', [ balance - qty, stock_id ]);
			
		} else {
			alert("erro!!!")
		}
		// transレコード追加
		var trans_id = alasql('SELECT MAX(id) + 1 as id FROM trans')[0].id;
		alasql('INSERT INTO trans VALUES(?,?,?,?,?,?)', [ trans_id, stock_id, dte, -qty, balance - qty, comm]);
		// リロード
		var book = {
				whouse: wo,
				item: ite,
				date: dte,
				qty: qty,
				comment: comm,
				};
		var jsonText = JSON.stringify(book);
		
		
//		tr.append("<input value="+jsonText+"><br>");
		tr.append("<div class='input-group'><input type='text' style='width: 700px' class='form-control' value="+jsonText+" aria-describedby='basic-addon1'></div><br>");
	
		$(elem).remove();
	}else{  $(elem).css("background-color","#f2dede");alarmm=1;  
//			as=balance;
//			$(elem).children("#bababa").text(as);
	}
		
		
	}
	// リロード
	if(alarmm==0){alert("出庫ができました");}
	else{alert("出庫できない品物があります");}
	
//	window.location.assign('in.html');
})
//通信ボタン
$("#camp").click(function(){
	var js=$("#text").val();
	var to=JSON.parse(js);
	
	var so=to.item;
	var ooo=so.slice(so.indexOf("[")+1, so.indexOf("]"));
//	var iteee=itee.slice(itee.indexOf("[")+1, itee.indexOf("]"));
	
	var ai = "addb"+syyy;
	syyy++;
	
	var wo=alasql('SELECT id FROM whouse WHERE name = ?', [ to.whouse ])[0].id;
	var ite=alasql('SELECT id FROM item WHERE code = ?', [ ooo ])[0].id;
	
	
	
	
	var rows = alasql('SELECT id, balance FROM stock WHERE whouse = ? AND item = ?', [ wo, ite ]);
	var stock_id, balance = 0;
	if (rows.length > 0) {
		balance = rows[0].balance;	}
	
	
	if (rows.length <=0){alert("在庫なし");} 
	else if((to.qty-rows[0].balance)>0){
		alert("在庫（"+rows[0].balance+"）不足");	}
	else{	
	if (to.qty<=0){alert("数量が０より大きくしてください");}
	else if(to.qty%1!=0){alert("整数を入力してください");}
	else{

	var tr = $('<tr>').appendTo('tbody#marks');
	tr.append('<td name="whouse">' + to.whouse + '</td>');
	tr.append('<td name="item">' +to.item+ '</td>');
	tr.append('<td name="date">' + to.date + '</td>');
	tr.append('<td name="qty">' + to.qty + '</td>');
//	tr.append('<td id="bababa">' + balance + '</td>');
	tr.append('<td name="comment">' + to.comment + '</td>');
	var td = $('<td class="text-right">').appendTo(tr);
	$("<a id="+ai+" onclick='haha(\""+ai+"\")' class='btn btn-xs btn-danger'>").html('<span class="glyphicon glyphicon-trash"></span> 削除').appendTo(td);
	$("#reflash").click();

}}})



//更新ボタン
$("#reflash").click(function(){

　　　//	make data
	var ss = ["洗足池商店","品川商店","虎ノ門商店","渋谷商店","新宿商店","海老名商店","目黒商店"];
	var com = ss[selectFrom(0, ss.length-1)];
	function selectFrom(lowerValue, upperValue) {
		var choices = upperValue - lowerValue + 1;
		return Math.floor(Math.random() * choices + lowerValue);
		}
	for (var i=0;i<1000;i++){
		var wh = selectFrom(1,4);
		var it = selectFrom(1,18);
		
		
	　　　//	
		var aa=alasql('SELECT name FROM whouse WHERE id = ?', [ wh ]);
		var bb=alasql('SELECT code,detail FROM item WHERE id = ?', [ it ]);
		var cc='[' + bb[0].code + ']' + bb[0].detail ;
		
		try {
			var nummm = alasql('SELECT balance FROM stock WHERE whouse = ? AND item = ?', [ wh,it])[0].balance; // generates an exception
			}
			catch (e) {
			   // statements to handle any exceptions
				continue; // pass exception object to error handler
			}
		if(nummm==0||nummm<0){continue; }	
		break;
		
	}	
	var nu = selectFrom(1,nummm);
	var time=today();	
	var book = {
			whouse: aa[0].name,
			item: cc,
			date: time,
			qty: nu,
			comment: com,
			};
	var jsonText = JSON.stringify(book);
	
　　　//	make qrcode
//	var typeNumber = 10;
//	var errorCorrectionLevel = 'L';
//	var qr = qrcode(typeNumber, errorCorrectionLevel);
//	qr.addData(jsonText);
//	qr.make();
//	document.getElementById('placeHolder').innerHTML = qr.createImgTag();
	
　　　//	make json
	$("#text").val(jsonText);
	
})
	
var btn = document.getElementById("reflash");
//创建事件对象
var event = document.createEvent("MouseEvents");
//初始化事件对象
event.initMouseEvent("click", true, true, document.defaultView, 0, 0, 0, 0, 0,
false, false, false, false, 0, null);
//触发事件
btn.dispatchEvent(event);


//get today
function today(){
var day = new Date();
	    if ( day.getYear() >= 2000 ){ var year = day.getYear() }
	    else {  var year = day.getYear() +1900 }
	    var month = day.getMonth()+1;
	    var date = day.getDate();
	        if (month < 10) {    //月.日が一桁の時頭に0を付ける処理
	            month = "0" + month;	                         }
	        if (date < 10) {
	            date = "0" + date;	                        }
	        var time=year+'-'+month+'-'+date;
	        return time;
}
//倉庫情報読み込み

function fresh1(){
	var rows = alasql('SELECT * FROM whouse;');
	for (var i = 0; i < rows.length; i++) {
	var row = rows[i];
	var option = $('<option>');
	option.attr('value', row.whouse.id);
	option.text(row.whouse.name);
	$('select[name="whouse"]').append(option);
}}
//　商品情報読み込み

function fresh2(){
	var rows = alasql('SELECT * FROM item;');
for (var i = 0; i < rows.length; i++) {
	var row = rows[i];
	var option = $('<option>');
	option.attr('value', row.item.id);
	option.text('[' + row.item.code + '] ' + row.item.detail);
	$('select[name="item"]').append(option);
}}
fresh1();
fresh2();

//手入力ボタン
$("#hand").click(function(){
	var text2=$("#hand").text();	
	if (text2=="手入力"){
		text2="手入力収納";		
		$("#erasable").slideDown(500);	}	
	else if(text2=="手入力収納"){
		text2="手入力";
		$("#erasable").slideUp(500);	}
	else{}
	$("#hand").text(text2);
})

//削除ボタン

function haha(ss){
	$("#"+ss+"").parents("tr").remove();
}