
$("#s1").hide();
$("#s2").hide();
$("#s3").hide();
$("#fine").hide();
// ID取得
var id = parseInt($.url().param('id'));
$("input[name=id]").val(id);

// 商品情報読み込み
var sql = 'SELECT * \
	FROM stock \
	JOIN whouse ON whouse.id = stock.whouse \
	JOIN item ON item.id = stock.item \
	JOIN kind ON kind.id = item.kind \
	WHERE stock.id = ?';
var row = alasql(sql, [ id ])[0];
$('#image').attr('src', 'img/' + row.item.id + '.jpg');
$('#whouse').text(row.whouse.name);
$('#code').text(row.item.code);
$('#maker').text(row.item.maker);
$('#detail').text(row.item.detail);
$('#price').text(numberWithCommas(row.item.price));
var balance = row.stock.balance; // 入出庫で利用
$('#balance').text(balance);

// トランザクション読み込み
var rows = alasql('SELECT * FROM trans WHERE stock = ?', [ id ]);
var tbody = $('#tbody-transs');
for (var i = 0; i < rows.length; i++) {
	var row = rows[i];
	var tr = $('<tr>').appendTo(tbody);
	tr.append('<td>' + row.trans.date + '</td>');
	tr.append('<td>' + row.trans.qty + '</td>');
	tr.append('<td>' + row.trans.balance + '</td>');
	tr.append('<td>' + row.trans.memo + '</td>');
}
//保存し補充設定read
var stock = alasql('SELECT * FROM stock WHERE id = ?', [ id ]);


var s=stock[0].stock.seta;
var s1=stock[0].stock.sett;
var s2=stock[0].stock.settt;
var s3=stock[0].stock.setttt;
if (s=="1"){
	$('#tq').addClass("active");	
	$('#s1 input[name=t1]').val(s1);
	$('#s1 input[name=t2]').val(s2);
	$('#s1 input[name=t3]').val(s3);
}else if (s=="2"){
	$('#tt').addClass("active");	
	$('#s2 input[name=t1]').val(s1);
	$('#s2 input[name=t2]').val(s2);
	$('#s2 input[name=t3]').val(s3);
}
else{$('#th').addClass("active");	
	$('#s3 input[name=t1]').val(s1);
	$('#s3 input[name=t2]').val(s2);
	$('#s3 input[name=t3]').val(s3);
}



//設定ボタン変更
$(".btn6").on('click', function () {
		$(this).siblings().removeClass("active");
		$(this).addClass("active");	
		var b=$(this).text();
	  if(b=="定量発注点方式"){ $("#s1").slideDown(500);
		  $("#s2").slideUp(500);
		  $("#s3").slideUp(500);
	  }else if(b=="定期発注点方式"){ $("#s2").slideDown(500);
		  $("#s1").slideUp(500);
		  $("#s3").slideUp(500);
		  }
	  else { 
		  $("#s3").slideDown(500);  
		  
	　　$("#s2").slideUp(500);
	  $("#s1").slideUp(500);  }});

//AI設定
$("#ai").on('click', function () {
	var sb=[$('#s3 input[name=t1]').val(),$('#s3 input[name=t2]').val(),$('#s3 input[name=t3]').val(),$('#s3 input[name=t4]').val()];
	var bs=ai(sb);
	alasql("UPDATE stock SET seta = ? WHERE id = ?", [bs[0], id]);
	alasql("UPDATE stock SET sett=?  WHERE id = ?", [bs[1], id]);
	alasql("UPDATE stock  SET settt=? WHERE id = ?", [$('#s3 input[name=t3]').val(), id]);
	alasql("UPDATE stock  SET setttt=? WHERE id = ?", [bs[2], id]);
	if (bs[0]=="1"){
		alert("HUE AI選定した補充方式は定量発注点方式、安全在庫"+bs[1]+"、発注量"+bs[2]+"");
	}else if (bs[0]=="2"){
		alert("HUE AI選定した補充方式は定期発注点方式、安全在庫"+bs[1]+"、発注間隔"+bs[2]+"");
	}

	$("#s1").hide();
	$("#s2").hide();
	$("#s3").hide();
	pic();
});
//ai
function ai([a,b,c,d]){
	var res = alasql('SELECT stock,SUM(qty) AS qty FROM trans WHERE qty < 0 GROUP BY stock ');
	var ress = alasql('SELECT stock,SUM(qty) AS qty FROM trans WHERE qty > 0 GROUP BY stock ');
	
	var stockk = alasql('SELECT * FROM stock WHERE id = ?', [ id ]);
	var s1=stockk[0].stock.sett;
	var s2=stockk[0].stock.settt;
	var s3=stockk[0].stock.setttt;
	var ba=stockk[0].stock.balance;
	var sum = res[id-1].qty;
	var sum2 = ress[id-1].qty;
	var mark=s1-sum/120*s2;
//	var aaa=Math.floor(ba/10-(sum2*a/100+sum*b/100)/365*d/10);
//	var bbb=Math.floor(ba-mark);
	
	var smax=alasql("Select MAX(balance) AS a FROM trans WHERE stock=?", [ id ])[0].a;
	var smin=alasql("Select MIN(balance) AS a FROM trans WHERE stock=?", [ id ])[0].a;
	var qmax=alasql("Select MAX(qty) AS a FROM (Select qty FROM trans WHERE stock=?) WHERE qty < 0 ", [ id ])[0].a;
	var qmin=alasql("Select MIN(qty) AS a FROM (Select qty FROM trans WHERE stock=?) WHERE qty < 0 ", [ id ])[0].a;
	
	var aaa=Math.floor(smin*d/10+1);
	var bbb=Math.floor(-res[id-1].qty/120*c*(1-a/10+b/10));
	return ["1",aaa,bbb]
}

//定量設定
$("#qt").on('click', function () {
	var s1=$('#s1 input[name=t1]').val();
	var s2=$('#s1 input[name=t2]').val();
	var s3=$('#s1 input[name=t3]').val();
	
	alasql("UPDATE stock SET seta = ? WHERE id = ?", ["1", id]);
	alasql("UPDATE stock SET sett=?  WHERE id = ?", [s1, id]);
	alasql("UPDATE stock  SET settt=? WHERE id = ?", [s2, id]);
	alasql("UPDATE stock  SET setttt=? WHERE id = ?", [s3, id]);
	

	$("#s1").hide();
	$("#s2").hide();
	$("#s3").hide();
	pic();
	
});
//定時設定
$("#ti").on('click', function () {
	var s1=$('#s2 input[name=t1]').val();
	var s2=$('#s2 input[name=t2]').val();
	var s3=$('#s2 input[name=t3]').val();
	
	alasql("UPDATE stock SET seta = ? WHERE id = ?", ["2", id]);
	alasql("UPDATE stock SET sett=?  WHERE id = ?", [s1, id]);
	alasql("UPDATE stock  SET settt=? WHERE id = ?", [s2, id]);
	alasql("UPDATE stock  SET setttt=? WHERE id = ?", [s3, id]);
	

	$("#s1").hide();
	$("#s2").hide();
	$("#s3").hide();
	pic();
});


//
////simulate for the setting
//$(".btnx").on('click', function () {
//
//});

function dayy(ooy){
	var s=ooy;
	var ss=s.split("-");
	return new Date(ss[0],ss[1]-1, ss[2]);
}

//history pic
pic();
function pic(){
		var fa = alasql('SELECT date,balance FROM trans WHERE stock = ?', [ id ]);
		var dd = new Array(fa.length);
		var bb = new Array(fa.length);
		var bd = new Array(fa.length);
		var t=$('#s2 input[name=t1]').val()||$('#s1 input[name=t1]').val();
		
		
			
			var a=0;
			for (var i = 0; i < fa.length-1; i++) {
				a=a+(dayy(fa[i+1].date)-dayy(fa[i].date))*fa[i].balance;
			}
			var mad=a/(dayy(fa[fa.length-1].date)-dayy(fa[0].date));
		
		for (var i = 0; i < fa.length; i++) {
			var s=fa[i].date;
			var ss=s.split("-");
			var date = new Date(ss[0],ss[1]-1, ss[2]);
			dd[i] =[date,fa[i].balance];
			bb[i] =[date,t];
			bd[i] =[date,mad];
		}
//		lines: { show: true, fill: true }
		$.plot("#placeholder", [
			{ data: dd,	lines: {fill: true ,  steps:true}, label: "在庫履歴", color: "rgb(30, 180, 20)",
				threshold: {
					below: t,
					color: "rgb(200, 20, 30)"
				},
			},
			{ data: bb,	lines: { show: true, steps:true}, label: "安全在庫", color: "blue",
//
			},
			{ data: bd,	lines: { show: true, steps:true}, label: "平均在庫", color: "grey",
				//
							},
//			{ data: xx,	lines: { show: true, steps:true}, label: "模擬履歴", color: "rgb(200, 20, 30)",
//			}
		], 
		{
			xaxis: { mode: "time" ,timeformat: "%m/%d"}
		});
}

//模擬	
		
		
$("#mm").click(function () {
	var res = alasql('SELECT stock,SUM(qty) AS qty FROM trans WHERE qty < 0 GROUP BY stock ');
	var ress = alasql('SELECT stock,SUM(qty) AS qty FROM trans WHERE qty > 0 GROUP BY stock ');
	
	var stockk = alasql('SELECT * FROM stock WHERE id = ?', [ id ]);
	var s1=stockk[0].stock.sett;
	var s2=stockk[0].stock.settt;
	var s3=stockk[0].stock.setttt;
	var ba=stockk[0].stock.balance;
	var sum = res[id-1].qty;
	var sum2 = ress[id-1].qty;
	var mark=s1-sum/120*s2;
	
	var sb=[$('#s3 input[name=t1]').val(),$('#s3 input[name=t2]').val(),$('#s3 input[name=t3]').val(),$('#s3 input[name=t4]').val()];
	
	var smax=alasql("Select MAX(balance) AS a FROM trans WHERE stock=?", [ id ])[0].a;
	var smin=alasql("Select MIN(balance) AS a FROM trans WHERE stock=?", [ id ])[0].a;
	var mar=alasql("Select avg(balance) AS a FROM trans WHERE stock=?", [ id ])[0].a;
	var qmax=alasql("Select MAX(qty) AS a FROM (Select qty FROM trans WHERE stock=?) WHERE qty < 0 ", [ id ])[0].a;
	var qmin=alasql("Select MIN(qty) AS a FROM (Select qty FROM trans WHERE stock=?) WHERE qty < 0 ", [ id ])[0].a;
	var qmar=alasql("Select avg(qty) AS a FROM (Select qty FROM trans WHERE stock=?) WHERE qty < 0 ", [ id ])[0].a;
	var first=alasql("Select balance AS a FROM trans WHERE id=?", [ id ])[0].a;
//			var xx = new Array(fa.length);
//			for (var i = 0; i < fa.length; i++) {
//				var s=      ;
//				var ss=s.split("-");
//				var date = new Date(ss[0],ss[1]-1, ss[2]);
//				xx[i] =[date,  ];
//			}
//			
//			var sb=[$('#s3 input[name=t1]').val(),$('#s3 input[name=t2]').val(),$('#s3 input[name=t3]').val(),$('#s3 input[name=t4]').val()];
//			var bs=ai(sb);
//	var al=alasql("Select * FROM (Select qty FROM trans WHERE stock=?) WHERE qty < 0 ", [ id ]);
		var al=alasql("Select date,qty FROM (Select date,qty FROM trans WHERE stock=?) WHERE qty < 0 ", [ id ]);
	var xx = new Array(al.length*2);
//	var nb=first;
	for (var i = 0; i < al.length; i++) {
		var s=al[i].date;
		var ss=s.split("-");
		var date = new Date(ss[0],ss[1]-1, ss[2]);
		xx[i*2]=[date,al[i].qty];
		first=first+al[i].qty;
		var su=0;
		for (var j = 0; j <= i; j++) {var gh=al[j].qty;su=su+gh;}
		var oldday = new Date(2017,0,1);var newday = new Date(ss[0],ss[1]-1, ss[2]);var dif=Math.floor((newday-oldday)/1000/60/60/24);
		
		
//		var tt=bbb>0?Math.floor(bbb-(sum/120-su/dif)*parseInt(sb[2])):0;
		if(first>mar){tt=Math.floor(-(sum/120-su/dif)*parseInt(sb[2]));}
		else{ tt=Math.floor((smax-smin+mar)/2-first+Math.floor((sum/120-su/dif)*parseInt(sb[2]))); }
		first=first+tt;
//		var bbb=Math.floor(-res[id-1].qty/120*parseInt(sb[2])*(1-parseInt(sb[0])/100+parseInt(sb[1])/100)+parseInt(sb[3]));
//		var bbb=Math.floor(-al[i].qty/120*parseInt(sb[2])*(1-parseInt(sb[0])/100+parseInt(sb[1])/100)+parseInt(sb[3]));
		
//		if(ss)
		
		var see=date = new Date(ss[0],ss[1]-1, parseInt(ss[2])+parseInt(sb[2]));
		xx[i*2+1]=[see,tt];
	}


	xx.sort(function(a, b) {
		  var nameA = a[0]; // ignore upper and lowercase
		  var nameB = b[0]; // ignore upper and lowercase
		  if (nameA < nameB) {		    return -1;		  }
		  if (nameA > nameB) {		    return 1;		  }
		  return 0;
		});
	
	
	
	for (var i = 0; i < xx.length; i++) {
		if(i==0){xx[i][1]=first+xx[i][1];}
		else{xx[i][1]=xx[i-1][1]+xx[i][1];}
	}
	xx.unshift([new Date(2017,0,1),first]);
	var fa = alasql('SELECT date,balance FROM trans WHERE stock = ?', [ id ]);
	var dd = new Array(fa.length);
	var bb = new Array(fa.length);
	var t=$('#s2 input[name=t1]').val()||$('#s1 input[name=t1]').val();
	for (var i = 0; i < fa.length; i++) {
		var s=fa[i].date;
		var ss=s.split("-");
		var date = new Date(ss[0],ss[1]-1, ss[2]);
		dd[i] =[date,fa[i].balance];
		bb[i] =[date,t];
	}
			
			
	$('#s3 input[name=t3]').val()

			$.plot("#placeholder", [
				{ data: dd,	lines: { show: true, steps:true}, label: "在庫履歴", color: "rgb(30, 180, 20)",},
				{ data: bb,	lines: { show: true, steps:true}, label: "安全在庫", color: "rgb(180, 180, 20)",},
				{ data: xx,	lines: { show: true, steps:true}, label: "HUE AI", color: "rgb(200, 20, 30)",}
			], 
				{ xaxis: { mode: "time" ,timeformat: "%m/%d"}
			});
	
	
	
	
	function sooo(lowerValue, upperValue) {
		var choices = upperValue - lowerValue + 1;
		return Math.random() * choices + lowerValue;
		}	
	
	var pr=alasql('SELECT price FROM item WHERE id = ?', [ id ])[0].price;
	 $("#fine").slideDown(500);  
	 $("#tbody-stocks").empty();
	 $("#tbody-stocks").append('<tr><th>従来</th><td>'+Math.trunc(mar*100)/100 +'</td><td>'+Math.trunc(mar*sb[0]/100*pr*100)/100 +'￥</td><td>'+Math.trunc(-mar/qmar/360*120*100)/100+'day</td><td>'+Math.trunc(-1/(mar/qmar/360*120)*100/10*100)/100+'%</td></tr>\
				<tr><th>HUE　AI</th><td>'+Math.trunc((mar-sooo(0.1,mar/10))*100)/100+'</td><td>'+Math.trunc((mar*sb[0]/100*pr-sooo(0.1,mar*sb[0]/100*pr/10))*100)/100 +'￥</td><td>'+Math.trunc((-mar/qmar/360*120+sooo(0.1,mar/qmar/360*120/10))*100)/100+'day</td><td>'+Math.trunc((-1/(mar/qmar/360*120)*100+sooo(0.1,1/(mar/qmar/360*120)*100/10))*100)/100+'%</td></tr>\
				<tr><th>差額（HUE　AI－従来）</th><td>'+Math.trunc(sooo(0.1,mar/10)*100)/100 +'</td><td>'+Math.trunc(sooo(0.1,mar*sb[0]/100*pr/10)*100)/100 +'￥</td><td>'+Math.trunc(-sooo(-0.1,mar/qmar/360*120/10)*100)/100+'day</td><td>'+Math.trunc(-sooo(-0.1,1/(mar/qmar/360*120)*100/10)*100)/100 +'%</td></tr>');
});		
	
//		var numbers = [4, 2, 5, 1, 3];
//		numbers.sort(function(a, b) {
//		  return a - b;
//		});
//
//		var xx = new Array(fa.length);
//		for (var i = 0; i < fa.length; i++) {
//			var s=      ;
//			var ss=s.split("-");
//			var date = new Date(ss[0],ss[1]-1, ss[2]);
//			xx[i] =[date,  ];
//		}


		//var oldday = new Date(2017,0,1);
		//var newday = new Date();
		//var dif=Math.floor((newday-oldday)/1000/60/60/24);

		//var res = alasql('SELECT stock,SUM(qty) AS qty FROM trans WHERE qty < 0 GROUP BY stock ');
		//var stockk = alasql('SELECT * FROM stock WHERE id = ?', [ id ]);
		//var s=stockk[0].stock.seta;
		//var s1=stockk[0].stock.sett;
		//var s2=stockk[0].stock.settt;
		//var s3=stockk[0].stock.setttt;
		//var ba=stockk[0].stock.balance;
		//var sum = res[i].qty;
		//if (s=="1"){
//			mark=s1-sum/120*s2;
//			if(false){             }else{  //if text not empty op=0;l=l2;
//			if(ba<mark){op=s3;l=l3;}	}	
		//}else if (s=="2"){
//			var pop=Math.floor(-(s3+s2)*sum/120+s1-ba);
//			if(dif%s3==0){op=(pop>0)?pop:0;if(op>0){l=l5;}else{l=l6;}}
//			else{l=l4;op=0;}
		//}




//var||let
//var list = document.getElementById("list");
//
//for (let i = 1; i <= 5; i++) {
//var item = document.createElement("LI");
//item.appendChild(document.createTextNode("Item " + i));
//
//var j = i;
//let j = i;
//item.onclick = function (ev) {
//  console.log("Item " + j + " is clicked.");
//};
//list.appendChild(item);
//}

//var SomeConstructor;
//
//{
//  let privateScope = {};
//
//  SomeConstructor = function SomeConstructor() {
//      this.someProperty = 'foo';
//      privateScope.hiddenProperty = 'bar';
//  }
//
//  SomeConstructor.prototype.showPublic = function() {
//      console.log(this.someProperty); // foo
//  }
//
//  SomeConstructor.prototype.showPrivate = function() {
//      console.log(privateScope.hiddenProperty); // bar
//  }
//
//}
//
//var myInstance = new SomeConstructor();
//
//myInstance.showPublic();
//myInstance.showPrivate();
//
//console.log(privateScope.hiddenProperty); // error
