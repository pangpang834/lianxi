$("#ksetting").hide();

//性能test
var start=Date.now();
var end=Date.now();
// set the typenames
var type2=["身上","住所","家族","学歴"];

var typemum = new Map();
typemum.set("身上","emp");
typemum.set("住所","addr");
typemum.set("家族","family");
typemum.set("学歴","edu");

var emptype = new Map();
emptype.set("社員番号","number");
emptype.set("氏名（漢字）","name_kanji");
emptype.set("氏名（カナ）","name_kana");
emptype.set("性別","sex");
emptype.set("生年月日","birthday");
emptype.set("連絡先電話番号","tel");
emptype.set("緊急連絡先氏名","ctct_name");
emptype.set("緊急連絡先住所","ctct_addr");
emptype.set("緊急連絡先電話番号","ctct_tel");
emptype.set("パスポート番号","pspt_no");
emptype.set("パスポート取得日付","pspt_date");
emptype.set("パスポート氏名","pspt_name");
emptype.set("貸与区分","rental");

var addrtype = new Map();
addrtype.set("郵便番号","zip");
addrtype.set("都道府県","state");
addrtype.set("市区町村","city");
addrtype.set("番地以降","street");
addrtype.set("建物名","bldg");
addrtype.set("住宅区分","house");

var familytype = new Map();
familytype.set("家族氏名（漢字）","fname_kanji");
familytype.set("家族氏名（カナ）","fname_kana");
familytype.set("家族性別","fsex");
familytype.set("家族生年月日","fbirthday");
familytype.set("続柄","relation");
familytype.set("同居区分","cohabit");
familytype.set("扶養区分","care");

var edutype = new Map();
edutype.set("学校名","school");
edutype.set("学部・学科・専攻名","major");
edutype.set("卒業年","grad");


var typeall = new Map();
typeall.set("社員番号","number");
typeall.set("氏名（漢字）","name_kanji");
typeall.set("氏名（カナ）","name_kana");
typeall.set("性別","sex");
typeall.set("生年月日","birthday");
typeall.set("連絡先電話番号","tel");
typeall.set("緊急連絡先氏名","ctct_name");
typeall.set("緊急連絡先住所","ctct_addr");
typeall.set("緊急連絡先電話番号","ctct_tel");
typeall.set("パスポート番号","pspt_no");
typeall.set("パスポート取得日付","pspt_date");
typeall.set("パスポート氏名","pspt_name");
typeall.set("貸与区分","rental");

typeall.set("郵便番号","zip");
typeall.set("都道府県","state");
typeall.set("市区町村","city");
typeall.set("番地以降","street");
typeall.set("建物名","bldg");
typeall.set("住宅区分","house");

typeall.set("家族氏名（漢字）","fname_kanji");
typeall.set("家族氏名（カナ）","fname_kana");
typeall.set("家族性別","fsex");
typeall.set("家族生年月日","fbirthday");
typeall.set("続柄","relation");
typeall.set("同居区分","cohabit");
typeall.set("扶養区分","care");

typeall.set("学校名","school");
typeall.set("学部・学科・専攻名","major");
typeall.set("卒業年","grad");

var type1=["社員番号","氏名（漢字）","性別","生年月日"];
var order=["","","up",""];
var search=["","","",""];
var 厚生年金=[type1,order,search];


var type1=["社員番号","氏名（漢字）","都道府県","家族氏名（漢字）","同居区分","扶養区分"];
var order=["","","up","","",""];
var search=["","","","","",""];
var 住民税=[type1,order,search];

var type1=["社員番号","氏名（漢字）","氏名（カナ）","性別","生年月日","連絡先電話番号"];
var type5 =["number","name_kanji","name_kana","sex","birthday","tel"];
var order=["up","","","","",""];
var search=["","","","","",""];
var firstset=[type1,order,search];
setset("firstset",firstset);


function down(){
	var manu=$.cookie();
	var fox=[];
	
	for (var key of Object.keys(manu)) {
		var io=readset1(key);
		io[0].unshift("type1");
		io[1].unshift("order");
		io[2].unshift("search");
		io[0].unshift(key);
		io[1].unshift(key);
		io[2].unshift(key);

	fox.push(io);
	}
	alasql.promise('SELECT * INTO CSV("aset.csv") FROM ?',[fox])
	.then(function(){console.log('Data saved');})
	.catch(function(err){console.log('Error:', err);});

}

function up(event){
      alasql('SELECT * FROM FILE(?,{headers:true})',[event],function(data){
    	  var n=data.length+1;
    	  for (var i=0;i<n;i++){
    		  if(i==0){var na=[];
    	    	  for (var v of Object.keys(data[i])) {
    	    		  var name;
    	    		  
    	    		  var vv = v.split(",").map(String);
    	    		  name=vv.shift();
	    			  var na1=vv.shift();
	    			  
    	    			  if(na1=="type1"){na[0]=vv;}
    	    			  else if(na1=="order"){na[1]=vv;}
    	    			  else if(na1=="search"){na[2]=vv;}
    	    		  	 
    	    	  }      setset(name,na);		  }
    		  else{var na=[];
    			  for (var v of Object.values(data[i-1])) {
    	    		  var name;
    	    		  
    	    		  var vv = v.split(",").map(String);
    	    		  name=vv.shift();
	    			  var na1=vv.shift();
    	    			  if(na1=="type1"){na[0]=vv;}
    	    			  else if(na1=="order"){na[1]=vv;}
    	    			  else if(na1=="search"){na[2]=vv;}
     	    			 
    	    	  }    setset(name,na);		  }    	  }
        
      });

   	readset("firstset");
   	window.location.reload(true);	
}

var syyy=0;
$.cookie.json = true;
$(function(){
	if ($.cookie("厚生年金")==null){setset("厚生年金",厚生年金);
	setset("住民税",住民税);}
//	$.removeCookie("_gat");
	var manu=$.cookie();
	var yu=0;
	for (var key of Object.keys(manu)) {
		if (key!="_gat"){
		var ss = "addb"+syyy;
		syyy++;
		if (yu==0){
		$("#setting").parents("ul").before("<ul id="+ss+" class='kkset nav navbar-nav'><li ><a id='2' href='#' onclick='haha(\""+ss+"\")'>"+key+"</a></li></ul>");
		yu++;
		}
		else{var tt = "addb"+(syyy-2);
			$("#"+tt+"").before("<ul id="+ss+" class='kkset nav navbar-nav'><li ><a id='2' href='#' onclick='haha(\""+ss+"\")'>"+key+"</a></li></ul>");
		}
		
	}}
	setset("firstset",firstset);
	readset("firstset");
});

function readset(setname) {
	var thisset = $.cookie(setname);
	if (thisset == null) alert("No set exist");
	if (thisset == undefined) alert("No set exist");
	drawset1(thisset);
//	drawpage(thisset);
}
function readset1(setname) {
	var thisset = $.cookie(setname);
	if (thisset == null) alert("No set exist");
	if (thisset == undefined) alert("No set exist");
return thisset;
}	
function setset(a,b) {
	$.cookie(a,b);
}
function destroy() {
var sname=$("#navbar-collapse li.active").find("a").text();
 // => true
if (sname=="個人情報管理"){alert("削除できません。")}
else{
	if (window.confirm('削除は取り消せません。よろしいですか？')) {
		$.removeCookie(sname);
//		$.cookie("testCounter",null);	
		window.location.reload(true);
	}}
}




$("#saveset").click(function(){
	var yo=$("#nowset").val();
	var sp=$("#navbar-collapse li.active").find("a").text();
	if(yo){
		var lista=[];
		$(".kkset").each(function(y) {
			lista.push($(this).find("a").text());
		});
		function filterFunc(index){
			if ((lista[index] == "個人情報管理")||(lista[index] == "破棄")||(lista[index] == "設定収納")){
				return false;
			}else{
				return true;
			}
		}
			var listb = lista.filter(filterFunc);
	
		if (yo=="個人情報管理"){alert("この保存名が使用できません。");}
		else if (yo=="新規"){alert("この保存名が使用できません。");}
		else if(listb.includes(yo))
			{	
				if (window.confirm('同じ '+sp+' の設定があります。書き覆ってよろしいですか？')) 
				{measures();
				var tempset=[type1,order,search];
				setset(yo,tempset);	
				if( $("#setts").text()=="破棄"){$("#setting").find("a").text("新規");$("#setting").find("a").css("color","");		}
				$("#nowset").val("");
				
				}			
			}
		else{
			var ss = "addb"+syyy;
			syyy++;
			$("#setting").parents("ul").before("<ul id="+ss+" class='kkset nav navbar-nav'><li ><a id='2' href='#' onclick='haha(\""+ss+"\")'>"+yo+"</a></li></ul>");
			measures();
			var tempset=[type1,order,search];
		    setset(yo,tempset);	
		   if( $("#setts").text()=="破棄"){$("#setting").find("a").text("設定収納");$("#setting").find("a").css("color","red");}
		   $("#nowset").val("");
		    
		}
}
	else{
		
		if (sp=="個人情報管理"){alert("保存名を入力してください。")}
		else{var sp=$("#navbar-collapse li.active").find("a").text();
			if (window.confirm('名前 '+sp+' の設定があります。書き覆ってよろしいですか？')) 
		{	measures();
			var tempset=[type1,order,search];
			setset(sp,tempset);	
			$("#nowset").val("");
		}	}	}
});

function measures(){
	type1=[];
	$(".ksetting td#types .active").each(function(index1){
		   var st = $(this).text();
		   type1.push(st);	  
	});
	type5 =type1.map(function(x) {var f="";	if (typeall.has(x)) {return typeall.get(x);	}});	
	
	$("[name=q2]").each(function(index1){
		  //var sst = $(this).text();
		var sst = $(this).val();
				  //if(sst!=""){}
		  search[index1]=sst;
		})
		var ssa=search.length;
	var ssb=type1.length;
	for(var i=0;i<(ssa-ssb);i++){
	search.pop();}
//		var st = $(".up").text().slice(0, -2);
//	if(st!=""){order[type1.indexOf(st)]="up";}
//	var stt = $(".down").text().slice(0, -2);
//	if(stt!=""){order[type1.indexOf(stt)]="down";}		
//	var j=type1.length;
//	for(var i=0;i<j;i++){
//		if(search[i]){
//			 searchtype = type5[i];
//			 searchtype2 =i;
//			 searchtype1 = type1[i];
//			 searchset = search[i];
//			}
//	}	
	
	order=[];
	for (var i = 0; i < type1.length; i++) {
		order[i]= "";
	}
	var st = $(".up").text().slice(0, -2);
	if(st!=""){order[type1.indexOf(st)]="up";}
	var stt = $(".down").text().slice(0, -2);
	if(stt!=""){order[type1.indexOf(stt)]="down";}	
	
	
	
};

var controler=0;

function haha(ss){
//function serf(){
	var sss=$("#"+ss+"").find("a").text();
	if((sss!="新規")&&(sss!="設定")&&(sss!="設定収納")){
	if ($("#"+ss+"").attr("class")!="active")
	{	$("#"+ss+"").parents("#navbar-collapse").find("li").removeClass("active");
	$("#"+ss+"").find("li").addClass("active");		
	}}
	
//	var sss=ss.trim();
	if (sss=="新規"){
		$("#ksetting").show(800);
		$("#"+ss+"").find("a").text("破棄");
		$("#"+ss+"").find("a").css("color","red");
		$("#nowset").attr("placeholder","入力してください。");
	}
	else if (sss=="破棄"){
//		$("#ksetting").hide(400);
//		$(this).find("a").text("新規");
//		$(this).find("a").css("color","");
//		readset("firstset");
//		$(".firstset").addClass("active");
//		$(this).find("li").removeClass("active");
		window.location.reload(true);
	}
	else if (sss=="設定"){
		$("#ksetting").show(800);
		$("#"+ss+"").find("a").text("設定収納");
		$("#"+ss+"").find("a").css("color","red");
		controler=1;
	}
	else if (sss=="設定収納"){
		$("#ksetting").hide(800);
		$("#"+ss+"").find("a").text("設定");
		$("#"+ss+"").find("a").css("color","");
		controler=0;
	}

	else if (sss=="個人情報管理"){
//		$("#setts").text("新規");
//		readset("firstset");
		window.location.reload(true);		
	}
	else {
		readset(sss);
		if(controler==0){$("#setts").text("設定");}else{}
//		$("#setts").text("設定");
		$("#nowset").attr("placeholder",sss);
		controler=1;
	}
};




var controler=0;

$(".kkset").click(function(){
//function serf(){
	var sss=$(this).find("a").text();
	if((sss!="新規")&&(sss!="設定")&&(sss!="設定収納")){
	if ($(this).attr("class")!="active")
	{	$(this).parents("#navbar-collapse").find("li").removeClass("active");
		$(this).find("li").addClass("active");		
	}}
	
//	var sss=ss.trim();
	if (sss=="新規"){
		$("#ksetting").show(800);
		$(this).find("a").text("破棄");
		$(this).find("a").css("color","red");
		$("#nowset").attr("placeholder","入力してください。");
	}
	else if (sss=="破棄"){
//		$("#ksetting").hide(400);
//		$(this).find("a").text("新規");
//		$(this).find("a").css("color","");
//		readset("firstset");
//		$(".firstset").addClass("active");
//		$(this).find("li").removeClass("active");
		window.location.reload(true);
	}
	else if (sss=="設定"){
		$("#ksetting").show(800);
		$(this).find("a").text("設定収納");
		$(this).find("a").css("color","red");
		controler=1;
	}
	else if (sss=="設定収納"){
		$("#ksetting").hide(800);
		$(this).find("a").text("設定");
		$(this).find("a").css("color","");
		controler=0;
	}

	else if (sss=="個人情報管理"){
//		$("#setts").text("新規");
//		readset("firstset");
		window.location.reload(true);		
	}
	else {
		readset(sss);
		if(controler==0){$("#setts").text("設定");}else{}
//		$("#setts").text("設定");
		$("#nowset").attr("placeholder",sss);
		controler=1;
	}
});







var alls=[];





function drawpage(theset){
	//draw the title
	$("th#tbody-remove").remove();//why it works??? id for multiple elements?????
	theset[0].forEach(function(y) {
		$("#tbody-type").append('<th id="tbody-remove">' + y + '</th>');	
	});
	
	
	var tbody = $('#tbody-emps');
	tbody.empty();
	
	//take all the info into alls
	
	var numm=0;
	var emps = alasql('SELECT * FROM emp', []);
	var el=emps.length;
	
	for (var i = 0; i < el; i++) {
		var emp = emps[i];
		var id =emp.id;
		var addrs = alasql('SELECT * FROM addr WHERE emp=?', [ id ]);
		var edus = alasql('SELECT * FROM edu WHERE emp=?', [ id ]);
		var families = alasql('SELECT * FROM family WHERE emp=?', [ id ]);
		var roots=[];
		var max=1;
		theset[0].forEach(function(z) {
			if (addrtype.has(z)) {max = Math.max(addrs.length , max);}
			if (edutype.has(z))  {max = Math.max(edus.length,max);}
			if (familytype.has(z))  {max = Math.max(families.length,max);}
		});

		for ( var j = 0; j < max ; j++){
			roots[j] =theset[0].map(function(x) {
				var f="";
				if (emptype.has(x)) {
					var sf=emptype.get(x);
					if(j==0){if (sf=="sex"){f=DB.choice(emp[sf]);}else{f=emp[sf];}}else{f="";}
				}
				else if (addrtype.has(x)) {
					var sf=addrtype.get(x);
					if(typeof addrs[j]=== 'undefined') {f="";}else{
					if (sf=="house"||sf=="state"){f=DB.choice(addrs[j][sf]);}else{f=addrs[j][sf];}
					if (typeof f === 'undefined') {f="";}}
				}
				else if (edutype.has(x)) {
					var sf=edutype.get(x);
					if(typeof edus[j]=== 'undefined') {f="";}else{
					f=edus[j][sf];
					if (typeof f === 'undefined') {f="";}}
				}
				else if (familytype.has(x)) {
					var sf=familytype.get(x);
					if(typeof families[j]=== 'undefined') {f="";}else{
					if (sf=="cohabit"||sf=="fsex"||sf=="care"){f=DB.choice(families[j][sf]);}else{f=families[j][sf];}
					if (typeof f === 'undefined') {f="";}}
				}
				else {
					alert("エラー301");		
				}
				return f
			});
			
			var ts=roots[j];
			ts.unshift(id);
			
			alls[numm]=ts;
			numm++;
		}	
	}
	
	var orderset;
	theset[1].forEach(function(element) {
	    if(element){orderset=element};
	});
	var ordertype2=theset[1].indexOf(orderset);
	var searchset;
	theset[2].forEach(function(element) {
	    if(element){searchset=element};
	});
	var searchtype2=theset[2].indexOf(searchset);
	searchtype2++;
	ordertype2++;
	//search and order
	var idss;
	if (searchset){ 
//		if (ordertype){ 
			if (orderset=="up"){idss = alasql('SELECT * FROM ? WHERE ['+searchtype2 +'] like "%'+ searchset +'%" ORDER BY ['+ordertype2+']', [alls]);}
			else{idss = alasql('SELECT * FROM ? WHERE ['+searchtype2 +'] like "%'+ searchset +'%" ORDER BY ['+ordertype2+'] DESC', [alls]);}}
//		else{idss = alasql('SELECT * FROM ? WHERE ['+searchtype2 +'] like "%'+ searchset +'%" ', [alls]);}	}
	else{
//		if(ordertype){
			if (orderset=="up"){idss = alasql('SELECT * FROM ? ORDER BY ['+ordertype2+']', [alls]);}
			else{idss = alasql('SELECT * FROM ? ORDER BY ['+ordertype2+'] DESC', [alls]);}}
//		else{idss = alasql('SELECT * FROM ? ', [alls]);}}
	//erase the double id
	var ids=[];
	var perm=[];
	for(i=0;i<idss.length;i++){
		var rs = idss[i][0];
		var mark=0;
		for (kk=0;kk<ids.length;kk++){
			if(ids[kk]==rs){mark=1}
		}
		if(mark==0){
			if (idss[i][ordertype2]!=""){ids.push(rs);}
			else{perm.push(rs);}	}
	}

	for(i=0;i<perm.length;i++){
		var rs = perm[i];
		var mark=0;
		for (kk=0;kk<ids.length;kk++){
			if(ids[kk]==rs){mark=1}
		}
		if(mark==0){ids.push(rs);}
	}
	//draw the date
	for (k=0;k<ids.length;k++){
		var ii=parseInt(ids[k], 10);
		//var emps = alasql('SELECT * FROM emp', []);
		var emp = emps[ii-1];
		var id =emp.id;
		var addrs = alasql('SELECT * FROM addr WHERE emp=?', [ id ]);
		var edus = alasql('SELECT * FROM edu WHERE emp=?', [ id ]);
		var families = alasql('SELECT * FROM family WHERE emp=?', [ id ]);

		var roots=[];
		var max=1;
		theset[0].forEach(function(z) {
			if (addrtype.has(z)) {max = Math.max(addrs.length , max);}
			if (edutype.has(z))  {max = Math.max(edus.length,max);}
			if (familytype.has(z))  {max = Math.max(families.length,max);}
		});
		
		for ( var j = 0; j < max ; j++){
			roots[j] =theset[0].map(function(x) {
				var f="";
				if (emptype.has(x)) {
					var sf=emptype.get(x);
					if(j==0){if (sf=="sex"){f=DB.choice(emp[sf]);}else{f=emp[sf];}}else{f="";}
				}
				else if (addrtype.has(x)) {
					var sf=addrtype.get(x);
					if(typeof addrs[j]=== 'undefined') {f="";}else{
					if (sf=="house"||sf=="state"){f=DB.choice(addrs[j][sf]);}else{f=addrs[j][sf];}
					if (typeof f === 'undefined') {f="";}}
				}
				else if (edutype.has(x)) {
					var sf=edutype.get(x);
					if(typeof edus[j]=== 'undefined') {f="";}else{
					f=edus[j][sf];
					if (typeof f === 'undefined') {f="";}}
				}
				else if (familytype.has(x)) {
					var sf=familytype.get(x);
					if(typeof families[j]=== 'undefined') {f="";}else{
					if (sf=="cohabit"||sf=="fsex"||sf=="care"){f=DB.choice(families[j][sf]);}else{f=families[j][sf];}
					if (typeof f === 'undefined') {f="";}}
				}
				else {
					alert("エラー301");		
				}
				return f
			});
			
		}	

		for ( var j = 0; j < max ; j++){
		var tr = $('<tr></tr>');
		if (j==0){tr.append('<td class="ha2"><img height=40 class="img-circle" src="img/' + emp.id + '.jpg"></td>');
		tr.append('<td><a href="emp.html?id=' + emp.id + '">' + emp.number + '</a></td>');}	
		else{tr.append('<td></td>');tr.append('<td>同上</td>');}
		roots[j].shift(); 
		roots[j].forEach(function(y) {
			tr.append('<td>' + y + '</td>');	
		});
		tr.appendTo(tbody);		
		}
		
	}
	
}	


function drawset(){

	
	var ordertype="";
	var orderset="";
	var searchtype="";
	var searchset="";

	var ordertype=$("#st1 .active").text().slice(0, -2);
//	var ordertype = typeall.get(sm);	
	var orderset =$("#st1 .active").hasClass("up")?"up":"dowm";
	

	var searchset=$("#st2 .active").val();
//	var searchtype =typeall.get($("#st2 .active").attr("placeholder"));	 
	var searchtype =$("#st2 .active").attr("placeholder");	 
	
	var mark1=0;
	var mark2=0;
	$(".ksetting td#types .active").each(function(index1){
		var st = $(this).text();
//		var st = typeall.has(sm)?typeall.get(sm):"";
		if (st==ordertype){mark1=1;}
		if (st==searchtype){mark2=1;}
	});

	if (mark1==0){
		//order[0]="up";
		orderset="up";
		ordertype="社員番号";};
	if (mark2==0){
		//search[0]="up";
		searchset="";
		searchtype="";};

	$(".btn1").parents("td").remove();
	$(".btn5").parents("td").remove();
	var o=0;
	var type1=[];
	$(".ksetting td#types .active").each(function(index1){
	   var st = $(this).text();
	   var oo ="orderbtn"+o;
	   o++;
	   type1.push(st);	 
	   
		if (st==ordertype){
		   if(orderset=="up"){$(".btn3").parents("td").before("<td><button id="+oo+" type='button' class='btn btn-default btn-block btn1 active up' onclick='orderbtn(\""+oo+"\")'>"+st+" ↑</button></td>");
		   		//mark1=1;
		   }
		   else{$(".btn3").parents("td").before("<td><button id="+oo+" type='button' class='btn btn-default btn-block btn1 active down' onclick='orderbtn(\""+oo+"\")'>"+st+" ↓</button></td>");
		   		//mark1=1;
		   }
		}  
		else{$(".btn3").parents("td").before("<td><button id="+oo+" type='button' class='btn btn-default btn-block btn1' onclick='orderbtn(\""+oo+"\")'>"+st+"</button></td>");}
		
		if (st==searchtype){$(".btn2").parents("td").before("<td><div class='form-group'><input name='q2' type='text' class='form-control btn5 active'  placeholder="+ searchtype+" value="+searchset+"></div></td>");
		}
		else{$(".btn2").parents("td").before("<td><div class='form-group'><input name='q2' type='text' class='form-control btn5' placeholder="+st+"></div></td>");}
	 
	  // $(".btn3").parents("td").before("<td><button id="+oo+" type='button' class='btn btn-default btn-block btn1' onclick='orderbtn(\""+oo+"\")'>"+st+"</button></td>");
	  // $(".btn2").parents("td").before("<td><div class='form-group'><input name='q2' type='text' class='form-control btn5' placeholder="+st+"></div></td>");
	})
	
	
	
//	$(".ksetting td#types .active").each(function(index1){
//		   var st = $(this).text();
//		   type1.push(st);	  
//	});
	var search=[];
	$("[name=q2]").each(function(index1){
		var sst = $(this).val();
		  search.push(sst);
	})
	var order=[];
	for (var i = 0; i < type1.length; i++) {
		order[i]= "";
	}
	var st = $(".up").text().slice(0, -2);
	if(st!=""){order[type1.indexOf(st)]="up";}
	var stt = $(".down").text().slice(0, -2);
	if(stt!=""){order[type1.indexOf(stt)]="down";}	
	
	
	
	setnow=[type1,order,search];
	
	$(".btn1").css("width","100%");
	$(".btn2").css("width","100px");
	$(".btn3").css("width","100px");
	//$(".btn3").css("width","70px");
	$(".btn1").css("float","left");
	$(".btn1").css("text-align","left");
	
	
	
	
	drawpage(setnow);
	
}

function drawset1(theset1){
	var type11=theset1[0];
	var order11=theset1[1];
	var search11=theset1[2];
//	for each (x in theset1[0]){
		$(".ksetting td#types button").each(function(index1){
			   var st = $(this).text();
			   var mark3=0;
			   for (i=0;i<type11.length;i++){
				   if (st==type11[i]){mark3=1;}			   }
			   if (mark3==1){$(this).addClass("active");}
			   else{$(this).removeClass("active");}  
			})
			
	drawset();		
			
	var st = $(".up").text().slice(0, -2);
	$(".up").text(st);
	$(".up").removeClass("active");
	$(".up").removeClass("up");
	var stt = $(".down").text().slice(0, -2);
	$(".down").text(stt);
	$(".down").removeClass("active");
	$(".down").removeClass("down");
			
	var mark4=1;
	for (i=0;i<order11.length;i++){
		if (order11[i]){ordertype=type11[i];orderset=order11[i];mark4=0;}
	}
	if(mark4==1	){ordertype = "社員番号";	 orderset = "up";}
	$("#st1 .btn1").each(function(index1){	
		if ($(this).text()==ordertype){
			$(this).addClass("active");
			if (orderset=="up"){$(this).addClass("up");
			$(this).text($(this).text()+" ↑");	
			}else{$(this).addClass("down");
			$(this).text($(this).text()+" ↓");	
			}
		}	
	})	
	
	var mark5=1;
	for (i=0;i<search11.length;i++){
		if (search11[i]){searchtype=type11[i];searchset=search11[i];mark5=0;}
	}
	if(mark5==1	){searchtype = "";	 searchset = "";}
	$("[name=q2]").each(function(index1){	
		if ($(this).attr("placeholder")==searchtype){
			$(this).addClass("active");
			$(this).val(searchset);}
		
	})		
	
	drawpage(theset1);			
}
	
	
	
	
	
	
	
	
	

//項目選択の設定--情報別項目一括選び

$(".btn-info").on('click', function () {
	//$("#2").css("color","red");
	
	if ($(this).attr("class")!="btn btn-info btn-lg active")
	{
		$(this).addClass("active");	
		$(this).parents("tr").find("#types button").addClass("active");
	}
	else{
		$(this).removeClass("active");
		$(this).parents("tr").find("#types button").removeClass("active");	
		$(".btn7").addClass("active");
	}
	drawset();

});

//項目選択boxの設定--項目選び
$(".btn-default.btn6").on('click', function () {
		

	if ($(this).attr("class")!="btn btn-default btn6 active")
	{
		$(this).addClass("active");			
	}
	else{
		$(this).removeClass("active");			
	}
	$(".btn7").addClass("active");	
	

	drawset();
	
});



//順番 設定

$("#st1 .btn1").on('click', function (){
	//alert("1");	
	
	type1=[];
	$(".ksetting td#types .active").each(function(index1){
		   var st = $(this).text();
		   type1.push(st);	  
	});
	type5 =type1.map(function(x) {var f="";	if (typeall.has(x)) {return typeall.get(x);	}});	
	
	$("[name=q2]").each(function(index1){
		  //var sst = $(this).text();
		var sst = $(this).val();
				  //if(sst!=""){}
		  search[index1]=sst;
		})
		var st = $(".up").text().slice(0, -2);
	if(st!=""){order[type1.indexOf(st)]="up";}
	var stt = $(".down").text().slice(0, -2);
	if(stt!=""){order[type1.indexOf(stt)]="down";}		
	var j=type1.length;
	for(var i=0;i<j;i++){
		if(search[i]){
			 searchtype = type5[i];
			 searchtype2 =i;
			 searchtype1 = type1[i];
			 searchset = search[i];
			}
	}	

	
	if ($(this).attr("class")=="btn btn-default btn-block btn1")
	{		
		$(this).parents("tr").find(".active").text($(this).parents("tr").find(".active").text().slice(0, -2));

		$(this).parents("tr").find(".btn1").removeClass("up");
		$(this).parents("tr").find(".btn1").removeClass("down");
		$(this).parents("tr").find(".btn1").removeClass("active");
		$(this).addClass("active");	
		$(this).addClass("up");	
		$(this).text($(this).text()+" ↑");	
	}
	else if($(this).attr("class")=="btn btn-default btn-block btn1 active up")
	{
		$(this).removeClass("up");		
		$(this).text($(this).text().slice(0, -2)+" ↓");		
		$(this).addClass("down");		
	}	
	else if($(this).attr("class")=="btn btn-default btn-block btn1 active down")
	{
		$(this).removeClass("active");	
		$(this).removeClass("down");
		$(this).text($(this).text().slice(0, -2));
	}	
	type1=[];
	$(".ksetting td#types .active").each(function(index1){
		   var st = $(this).text();
		   
		   type1.push(st);	 }); 
	for (var i = 0; i < type1.length; i++) {
		  order[i]= "";
		}
	var st = $(".up").text().slice(0, -2);
	if(st!=""){order[type1.indexOf(st)]="up";}
	var stt = $(".down").text().slice(0, -2);
	if(stt!=""){order[type1.indexOf(stt)]="down";}	   
	
	var j =type1.length;

	var so = 0;
	for(var i=0;i<j;i++){
		if(order[i]!=""){
			so=1;
			 ordertype = type5[i];
			 ordertype2 = i;
			 ordertype1 = type1[i];
			 orderset = order[i];
			}
	}
	if(so==0){
		 ordertype = "number";
		 ordertype2 = 0;
		 ordertype1 = "社員番号";
		 orderset = "up";
	}
	
		
	
	drawset();
});


//順番設定
function orderbtn(oo){
	//alert("1");	
	
	type1=[];
	$(".ksetting td#types .active").each(function(index1){
		   var st = $(this).text();
		   type1.push(st);	  
	});
	type5 =type1.map(function(x) {var f="";	if (typeall.has(x)) {return typeall.get(x);	}});	
	
	$("[name=q2]").each(function(index1){
		  //var sst = $(this).text();
		var sst = $(this).val();
				  //if(sst!=""){}
		  search[index1]=sst;
		})
		var st = $(".up").text().slice(0, -2);
	if(st!=""){order[type1.indexOf(st)]="up";}
	var stt = $(".down").text().slice(0, -2);
	if(stt!=""){order[type1.indexOf(stt)]="down";}		
	var j=type1.length;
	for(var i=0;i<j;i++){
		if(search[i]){
			 searchtype = type5[i];
			 searchtype2 =i;
			 searchtype1 = type1[i];
			 searchset = search[i];
			}
	}	

	if ($("#"+oo+"").attr("class")=="btn btn-default btn-block btn1")
	{		
		$("#"+oo+"").parents("tr").find(".active").text($("#"+oo+"").parents("tr").find(".active").text().slice(0, -2));

		$("#"+oo+"").parents("tr").find(".btn1").removeClass("up");
		$("#"+oo+"").parents("tr").find(".btn1").removeClass("down");
		$("#"+oo+"").parents("tr").find(".btn1").removeClass("active");
		$("#"+oo+"").addClass("active");	
		$("#"+oo+"").addClass("up");	
		$("#"+oo+"").text($("#"+oo+"").text()+" ↑");	
	}
	else if($("#"+oo+"").attr("class")=="btn btn-default btn-block btn1 active up")
	{
		$("#"+oo+"").removeClass("up");		
		$("#"+oo+"").text($("#"+oo+"").text().slice(0, -2)+" ↓");		
		$("#"+oo+"").addClass("down");		
	}	
	else if($("#"+oo+"").attr("class")=="btn btn-default btn-block btn1 active down")
	{
		$("#"+oo+"").removeClass("active");	
		$("#"+oo+"").removeClass("down");
		$("#"+oo+"").text($("#"+oo+"").text().slice(0, -2));
	}	
	type1=[];
	$(".ksetting td#types .active").each(function(index1){
		   var st = $(this).text();
		   type1.push(st);});  
	for (var i = 0; i < type1.length; i++) {
		  order[i]= "";
		}
	var st = $(".up").text().slice(0, -2);
	if(st!=""){order[type1.indexOf(st)]="up";}
	var stt = $(".down").text().slice(0, -2);
	if(stt!=""){order[type1.indexOf(stt)]="down";}	   
	
	var j =type1.length;
	var so = 0;
	for(var i=0;i<j;i++){
		if(order[i]!=""){
			so=1;
			 ordertype = type5[i];
			 ordertype2 = i;
			 ordertype1 = type1[i];
			 orderset = order[i];
			}
	}
	if(so==0){
		 ordertype = "number";
		 ordertype2 = 0;
		 ordertype1 = "社員番号";
		 orderset = "up";
	}	

drawset();
};




//順番検索の設定

$(".btn2").on('click', function (){
	searchtype="";
	searchtype1="";
	searchtype2="";
	searchset="";
	$(".ksetting td#types .active").each(function(index1){
		   var st = $(this).text();
		   type1.push(st);	 }); 
	$("[name=q2]").removeClass("active");
	$("[name=q2]").each(function(index1){
		  //var sst = $(this).text();
		var sst = $(this).val();
		if (sst){$(this).addClass("active");};
				  //if(sst!=""){}
		  search[index1]=sst;
		})
		
	var j =type1.length;	
	for(var i=0;i<j;i++){
		if(search[i]){
			 searchtype = type5[i];
			 searchtype2 =i;
			 searchtype1 = type1[i];
			 searchset = search[i];
			}
	}	

	drawset();
});



















//hide box の操作と設定
$("#kset").click(function(){
	var text2=$("#kset").text();	
	if (text2=="表示項目の設定"){
		text2="表示項目の収納";		
		$("#kset").css("background-color","olive");
		$(".ksetting").slideDown(500);
	}	
	else if(text2=="表示項目の収納"){
		text2="表示項目の設定";
		//$("#kset").css("color","");
		$("#kset").css("background-color","");
		$(".ksetting").slideUp(500);
	}
	else{}
	$("#kset").text(text2);
	
})

$("#setting").click(function(){
	var text1=$("#set").text();
	if (text1=="設定展開"){
		text1="設定収納";
		$("#set").css("color","blue");
		$(".setting").slideDown(500);
	}	
	else if(text1=="設定収納"){
		text1="設定展開";
		$("#set").css("color","");
		$(".setting").slideUp(500);
		$(".ksetting").slideUp(500);
		
		$("#kset").css("background-color","");
		$("#kset").text("表示項目の設定");
		
	}
	else{}
	$("#set").text(text1);	
})

$(".btn1").css("width"," 100%");
$(".btn1").css("text-align","left");

function readall(){
//	var s=type1;
//	var ss=["id",s];
//	var alls=[ss,alls];
};


$("#txt").click(function(){
	readall();	
	$('#tableID').tableExport({type:'pdf',
        jspdf: {orientation: 'l',
                format: 'a3',
                margins: {left:10, right:10, top:20, bottom:20},
                autotable: {styles: {fillColor: 'inherit', 
                                     textColor: 'inherit'},
                            tableWidth: 'auto'}
               }
       });
//
//	alasql.promise('SELECT * INTO TXT("my.txt") FROM ?',[alls])
//	.then(function(){console.log('Data saved');})
//	.catch(function(err){console.log('Error:', err);});
//	alert("coming soon");
})
$("#csv").click(function(){
	readall();	
	alasql.promise('SELECT * INTO CSV("my.csv", {headers:false}) FROM ?',[alls])
	.then(function(){console.log('Data saved');})
	.catch(function(err){console.log('Error:', err);});
})
$("#xls").click(function(){
	readall();	
	alasql.promise('SELECT * INTO XLS("my.XLS", {headers:false}) FROM ?',[alls])
	.then(function(){console.log('Data saved');})
	.catch(function(err){console.log('Error:', err);});
})
//$("#xlsxml").click(function(){
//	readall();	
//	alasql.promise('SELECT * INTO XLSXML("my.xlsxml", {headers:false}) FROM ?',[alls])
//	.then(function(){console.log('Data saved');})
//	.catch(function(err){console.log('Error:', err);});
//})
$("#json").click(function(){
	readall();	
	alasql.promise('SELECT * INTO Json("my.Json", {headers:false}) FROM ?',[alls])
	.then(function(){console.log('Data saved');})
	.catch(function(err){console.log('Error:', err);});
})





//追加ボタン用
//function clicktype2(tt) {
//	if ($("#"+tt+"").attr("class")!="btn btn-info btn-lg active")
//	{
//		$("#"+tt+"").addClass("active");	
//		$("#"+tt+"").parents("tr").find("#types button").addClass("active");
//	}
//	else{
//		$("#"+tt+"").removeClass("active");
//		$("#"+tt+"").parents("tr").find("#types button").removeClass("active");		
//	}	
//	setset();
//	setpage();
//};
//追加ボタン用
//function clicktype(rr) {
//	//$("#2").css("color","red");
//	if ($("#"+rr+"").attr("class")!="btn btn-default btn6 active")
//	{
//		$("#"+rr+"").addClass("active");			
//	}
//	else{
//		$("#"+rr+"").removeClass("active");			
//	}	
//	setset();
//	setpage();
//};











//function setset(){
//	type1=[];
//	
////	var a1=ordertype;
////	var a2=ordertype1;
////	var a3=ordertype2;
////	var a4=ordertype3;
////	var a9=orderset;
////	var a5=searchtype;
////	var a6=searchtype1;
////	var a7=searchtype2;
////	var a8=searchset;
//	
//	
//	$(".btn1").parents("td").remove();
//	$(".btn5").parents("td").remove();
//	var mark1=0;
//	var mark2=0;
//	$(".ksetting td#types .active").each(function(index1){
//	   var st = $(this).text();
//	   var oo ="orderbtn"+o;
//	   o++;
//	   type1.push(st);	 
//	   
//		if (st==ordertype1){
//		   if(orderset=="up"){$(".btn3").parents("td").before("<td><button id="+oo+" type='button' class='btn btn-default btn-block btn1 active up' onclick='orderbtn(\""+oo+"\")'>"+st+" ↑</button></td>");
//		   		mark1=1;
//		   }
//		   else{$(".btn3").parents("td").before("<td><button id="+oo+" type='button' class='btn btn-default btn-block btn1 active down' onclick='orderbtn(\""+oo+"\")'>"+st+" ↓</button></td>");
//		   		mark1=1;
//		   }
//		}  
//		else{$(".btn3").parents("td").before("<td><button id="+oo+" type='button' class='btn btn-default btn-block btn1' onclick='orderbtn(\""+oo+"\")'>"+st+"</button></td>");}
//		
//		if (st==searchtype1){$(".btn2").parents("td").before("<td><div class='form-group'><input name='q2' type='text' class='form-control btn5' value="+searchset+"></div></td>");
//		mark2=1;
//		}
//		else{$(".btn2").parents("td").before("<td><div class='form-group'><input name='q2' type='text' class='form-control btn5' placeholder="+st+"></div></td>");}
//	 
//	  // $(".btn3").parents("td").before("<td><button id="+oo+" type='button' class='btn btn-default btn-block btn1' onclick='orderbtn(\""+oo+"\")'>"+st+"</button></td>");
//	  // $(".btn2").parents("td").before("<td><div class='form-group'><input name='q2' type='text' class='form-control btn5' placeholder="+st+"></div></td>");
//	})
//	
//	if (mark1==0){
//		orderset="";
//		ordertype="";
//		ordertype1="";
//		ordertype2="";
//		ordertype3="";	
//	}
//
//	
//	if (mark2==0){	
//		searchtype="";
//		searchtype1="";
//		searchtype2="";
//		searchset="";
//	}
//
//	$("#stitle1").css("width","100px");
//	$("#stitle2").css("width","100px");	
//	$("#stitle").css("width","100px");
//	$(".btn1").css("width","100%");
//	$(".btn2").css("width","100px");
//	//$(".btn3").css("width","70px");
//	$(".btn1").css("float","left");
//	$(".btn1").css("text-align","left");
//
//	//type5 =type1.map(function(x) {var f="";	if (typeall.has(x)) {return typeall.get(x);	}});
//
//	type1=[];
//	$(".ksetting td#types .active").each(function(index1){
//		   var st = $(this).text();
//		   type1.push(st);	  
//	});
//	type5 =type1.map(function(x) {var f="";	if (typeall.has(x)) {return typeall.get(x);	}});	
//	
//	$("[name=q2]").each(function(index1){
//		  //var sst = $(this).text();
//		var sst = $(this).val();
//				  //if(sst!=""){}
//		  search[index1]=sst;
//		})
//	for (var i = 0; i < type1.length; i++) {
//			order[i]= "";
//		}
//	var st = $(".up").text().slice(0, -2);
//	if(st!=""){order[type1.indexOf(st)]="up";}
//	var stt = $(".down").text().slice(0, -2);
//	if(stt!=""){order[type1.indexOf(stt)]="down";}		
//	var j=type1.length;
//	for(var i=0;i<j;i++){
//		if(search[i]){
//			 searchtype = type5[i];
//			 searchtype2 =i;
//			 searchtype1 = type1[i];
//			 searchset = search[i];
//			}
//	}	
//	
//	var so = 0;
//	for(var i=0;i<j;i++){
//		if(order[i]!=""){
//			so=1;
//			 ordertype = type5[i];
//			 ordertype2 = i;
//			 ordertype1 = type1[i];
//			 orderset = order[i];
//			}
//	}
//	if(so==0){
//		 ordertype = "number";
//		 ordertype2 = 0;
//		 ordertype1 = "社員番号";
//		 orderset = "up";
//	}	
//	
//	
//	
////	setpage();
//};	




	


//社員一覧表示

//function setpage(){	
//	var type1=[];		
//	$(".ksetting td#types .active").each(function(index1){
//		var st = $(this).text();
//		type1.push(st);		
//		});
//	
//	$("th#tbody-remove").remove();
//	type1.forEach(function(y) {
//		$("#tbody-type").append('<th id="tbody-remove">' + y + '</th>');	
//	});
//	//type1.shift(); 
//		
//	var tbody = $('#tbody-emps');
//	tbody.empty();
//
//	var alls=[];
//	var numm=0;
//	for (var i = 0; i < emps.length; i++) {
//		var emp = emps[i];
//		var id =emp.id;
//		var addrs = alasql('SELECT * FROM addr WHERE emp=?', [ id ]);
//		var edus = alasql('SELECT * FROM edu WHERE emp=?', [ id ]);
//		var families = alasql('SELECT * FROM family WHERE emp=?', [ id ]);
//		var roots=[];
//		var max=1;
//		type1.forEach(function(z) {
//			if (addrtype.has(z)) {max = Math.max(addrs.length , max);}
//			if (edutype.has(z))  {max = Math.max(edus.length,max);}
//			if (familytype.has(z))  {max = Math.max(families.length,max);}
//		});
//		
//
//		for ( var j = 0; j < max ; j++){
//			roots[j] =type1.map(function(x) {
//				var f="";
//				if (emptype.has(x)) {
//					var sf=emptype.get(x);
//					if(j==0){if (sf=="sex"){f=DB.choice(emp[sf]);}else{f=emp[sf];}}else{f="";}
//				}
//				else if (addrtype.has(x)) {
//					var sf=addrtype.get(x);
//					if(typeof addrs[j]=== 'undefined') {f="";}else{
//					if (sf=="house"||sf=="state"){f=DB.choice(addrs[j][sf]);}else{f=addrs[j][sf];}
//					if (typeof f === 'undefined') {f="";}}
//				}
//				else if (edutype.has(x)) {
//					var sf=edutype.get(x);
//					if(typeof edus[j]=== 'undefined') {f="";}else{
//					f=edus[j][sf];
//					if (typeof f === 'undefined') {f="";}}
//				}
//				else if (familytype.has(x)) {
//					var sf=familytype.get(x);
//					if(typeof families[j]=== 'undefined') {f="";}else{
//					if (sf=="cohabit"||sf=="sex"||sf=="care"){f=DB.choice(families[j][sf]);}else{f=families[j][sf];}
//					if (typeof f === 'undefined') {f="";}}
//				}
//				else {
//					alert("エラー301");		
//				}
//				return f
//			});
//			
//			
//			var ts=roots[j];
//			ts.unshift(id);
//			
//			alls[numm]=ts;
//			numm++;
//		}	
//	}
//
//	searchtype2++;
//	ordertype2++;
//	var idss;
//	if (searchset){ 
//		if (ordertype){ 
//			if (orderset=="up"){idss = alasql('SELECT * FROM ? WHERE ['+searchtype2 +'] like "%'+ searchset +'%" ORDER BY ['+ordertype2+']', [alls]);}
//			else{idss = alasql('SELECT * FROM ? WHERE ['+searchtype2 +'] like "%'+ searchset +'%" ORDER BY ['+ordertype2+'] DESC', [alls]);}}
//		else{idss = alasql('SELECT * FROM ? WHERE ['+searchtype2 +'] like "%'+ searchset +'%" ', [alls]);}	}
//	else{
//		if(ordertype){
//			if (orderset=="up"){idss = alasql('SELECT * FROM ? ORDER BY ['+ordertype2+']', [alls]);}
//			else{idss = alasql('SELECT * FROM ? ORDER BY ['+ordertype2+'] DESC', [alls]);}}
//		else{idss = alasql('SELECT * FROM ? ', [alls]);}}
//	
//	var ids=[];
//	var perm=[];
//	for(i=0;i<idss.length;i++){
//		var rs = idss[i][0];
//		//ids.push(rs);
//		var mark=0;
//		for (kk=0;kk<ids.length;kk++){
//			if(ids[kk]==rs){mark=1}
//		}
//		
//		if(mark==0){
//			if (idss[i][ordertype2]!=""){ids.push(rs);}
//			else{perm.push(rs);}	}
//	}
//
//	for(i=0;i<perm.length;i++){
//		var rs = perm[i];
//		var mark=0;
//		for (kk=0;kk<ids.length;kk++){
//			if(ids[kk]==rs){mark=1}
//		}
//		if(mark==0){ids.push(rs);}
//	}
//	
//
//		
//	for (k=0;k<ids.length;k++){
//		var ii=parseInt(ids[k], 10);
//		var emp = emps[ii-1];
//		var id =emp.id;
//		var addrs = alasql('SELECT * FROM addr WHERE emp=?', [ id ]);
//		var edus = alasql('SELECT * FROM edu WHERE emp=?', [ id ]);
//		var families = alasql('SELECT * FROM family WHERE emp=?', [ id ]);
//
//		var roots=[];
//		var max=1;
//		type1.forEach(function(z) {
//			if (addrtype.has(z)) {max = Math.max(addrs.length , max);}
//			if (edutype.has(z))  {max = Math.max(edus.length,max);}
//			if (familytype.has(z))  {max = Math.max(families.length,max);}
//		});
//		
//		for ( var j = 0; j < max ; j++){
//			roots[j] =type1.map(function(x) {
//				var f="";
//				if (emptype.has(x)) {
//					var sf=emptype.get(x);
//					if(j==0){if (sf=="sex"){f=DB.choice(emp[sf]);}else{f=emp[sf];}}else{f="";}
//				}
//				else if (addrtype.has(x)) {
//					var sf=addrtype.get(x);
//					if(typeof addrs[j]=== 'undefined') {f="";}else{
//					if (sf=="house"||sf=="state"){f=DB.choice(addrs[j][sf]);}else{f=addrs[j][sf];}
//					if (typeof f === 'undefined') {f="";}}
//				}
//				else if (edutype.has(x)) {
//					var sf=edutype.get(x);
//					if(typeof edus[j]=== 'undefined') {f="";}else{
//					f=edus[j][sf];
//					if (typeof f === 'undefined') {f="";}}
//				}
//				else if (familytype.has(x)) {
//					var sf=familytype.get(x);
//					if(typeof families[j]=== 'undefined') {f="";}else{
//					if (sf=="cohabit"||sf=="sex"||sf=="care"){f=DB.choice(families[j][sf]);}else{f=families[j][sf];}
//					if (typeof f === 'undefined') {f="";}}
//				}
//				else {
//					alert("エラー301");		
//				}
//				return f
//			});
//			
//		}	
//
//
////var res =   alasql('SELECT [0] FROM ? ORDER BY ['+ordertype2+']', [alls]);
////var res1 =  alasql('SELECT * FROM ? ORDER BY ['+ordertype2+']', [alls]);
//		for ( var j = 0; j < max ; j++){
//		var tr = $('<tr></tr>');
//		if (j==0){tr.append('<td><img height=40 class="img-circle" src="img/' + emp.id + '.jpg"></td>');tr.append('<td><a href="emp.html?id=' + emp.id + '">' + emp.number + '</a></td>');}	
//		else{tr.append('<td></td>');tr.append('<td>同上</td>');}
//		roots[j].shift(); 
//		roots[j].forEach(function(y) {
//			tr.append('<td>' + y + '</td>');	
//		});
//		tr.appendTo(tbody);		
//		}
//		
//	}
//	
//
//	
//	
//
//}	












/*///////given example///////////save until figure out how it works/////////////////////////////////////////////////////////////////
// リクエストパラメータを取得
var q1 = $.url().param('q1');
$('input[name="q1"]').val(q1);
var q2 = $.url().param('q2');
$('input[name="q2"]').val(q2);

// データベース読み込み
var emps;
if (q1) {
	emps = alasql('SELECT * FROM emp WHERE number LIKE ?', [ '%' + q1 + '%' ]);
	
} else if (q2) {
	q2 = '%' + q2 + '%';
	emps = alasql('SELECT * FROM emp WHERE name_kanji LIKE ? OR name_kana LIkE ?', [ q2, q2 ]);
} else {
	
}

*//////////////////////////////////////////////////////////////////////////////////////



//////追加ボタンｓ/////////////save////////////////////////////
/*

//追加text フォマード
$(".form-control.type").css("width","70px");
$(".btn-info").css("width","100px");


//追加操作ーー情報別
var s=0;
var t=0;
$("button#addtype2").on('click', function addtype2() {
	//alert("11111");
	var ss = "addtype"+s;
	s++;
	var tt ="clicktype2"+t;
	t++;
	var newtype2 = $(this).parents("div.input-group").find("input").val();
	//alert(newtype2);
	var idx = type2.indexOf(newtype2);
	if (idx !=-1){alert("情報別が存在しました。");}else{	
	if (newtype2==""){alert("情報別を入力してください。");}else{	
	$(this).parents("tr#addtype2").before("<tr><th id='stitle'><button id="+tt+" type='button' class='btn btn-info btn-lg' onclick='clicktype2(\""+tt+"\")'>"+newtype2+"</button></th><td id='types'></td><td><div class='input-group'><input type='text' class='form-control type' placeholder='項目' ><span class='input-group-btn'><button id="+ss+" type='button' class='btn btn-success' onclick='addtype(\""+ss+"\")'>追加</button></span></div></td></tr>");
	//$(this).parents("tr#addtype2").before("<tr><th id='stitle'><button id='type' type='button' class='btn btn-info btn-lg' onclick='clicktype2()'>"+newtype2+"</button></th><td id='types'></td><td><div class='input-group'><input type='text' class='form-control type' placeholder='項目' ><span class='input-group-btn'><button id="+ss+" type='button' class='btn btn-success' onclick='addtype()'>追加</button></span></div></td></tr>");
	$(".btn1").css("width"," 100%");
	$(".btn1").css("text-align","left");
	$(".form-control.type").css("width","70px");
	$(".btn-info").css("width","100px");
	type2.push(newtype2);
	}}	
});

//追加操作ーー項目
var r=0;
$("button#addtype").on('click', function (){
	//alert("1");	
	var rr = "clicktype"+r;
	r++;
	var newtype = $(this).parents("div.input-group").find("input").val();
		
	if (newtype==""){alert("項目を入力してください。");}else{	
	//alert(newtype);
	$(this).parents("tr").find("td#types").append("<button id="+rr+" type='button' class='btn btn-default btn6' onclick='clicktype(\""+rr+"\")'>"+newtype+"</button>");
	}
	$(".btn1").css("width"," 100%");
	$(".btn1").css("text-align","left");
	$(".form-control.type").css("width","70px");
	$(".btn-info").css("width","100px");
});
function addtype(ss) {
	var rr = "clicktype"+r;
	r++;
	var newtype = $("#"+ss+"").parents("div.input-group").find("input").val();
	//if (newtype==""){alert("項目を入力してください。");}else{	
	//alert(newtype);
	$("#"+ss+"").parents("tr").find("td#types").append("<button id="+rr+" type='button' class='btn btn-default btn6' onclick='clicktype(\""+rr+"\")'>"+newtype+"</button>");
	//}
	$(".btn1").css("width"," 100%");
	$(".btn1").css("text-align","left");
	$(".form-control.type").css("width","70px");
	$(".btn-info").css("width","100px");	
};
*/////////////////////////////////////////////////////////////



/*//////for test////////save forever///////////////////////////////////////////////
//
//$.cookie.json = true;
//function readFunc() {
//	myCounter = $.cookie("testCounter");
//	if (myCounter == null) myCounter = [type1,type5,ordertype,orderset];
//	dispCountFunc();
//}
//			
//function dispCountFunc() {
//	$("div#cookietest").text("いままでのクリック回数は"+myCounter+"回です。")
//}
//
//$(function(){
//	readFunc();
//			
//	$("#count").click(function(){
//		var st=myCounter[1][1]+1;
//		myCounter[1][1]=st;
//		$.cookie("testCounter",myCounter);
//		dispCountFunc();
//	})
//});

//var emps1 = alasql('SELECT * FROM emp LEFT JOIN family ON emp.id=family.emp');
//var emps2 = alasql('SELECT * FROM emp RIGHT JOIN family ON emp.id=family.emp');
//var emps3 = alasql('SELECT * FROM emp INNER JOIN family ON emp.id=family.emp');
var emps4 = alasql('SELECT * FROM emp OUTER JOIN family ON emp.id=family.emp');

var emps5 = alasql('SELECT * FROM emp OUTER JOIN family ON emp.id=family.emp LEFT JOIN addr ON emp.id=addr.emp');
//var emps6 = alasql('SELECT * FROM emp OUTER JOIN family ON emp.id=family.emp RIGHT JOIN addr ON emp.id=addr.emp');
//var emps7 = alasql('SELECT * FROM emp OUTER JOIN family ON emp.id=family.emp INNER JOIN addr ON emp.id=addr.emp');
var emps8 = alasql('SELECT * FROM emp OUTER JOIN family ON emp.id=family.emp OUTER JOIN addr ON emp.id=addr.emp');

var emps51 = alasql('SELECT * FROM emp OUTER JOIN family ON emp.id=family.emp LEFT JOIN addr ON emp.id=addr.emp LEFT JOIN edu ON emp.id=edu.emp');
//var emps52 = alasql('SELECT * FROM emp OUTER JOIN family ON emp.id=family.emp LEFT JOIN addr ON emp.id=addr.emp RIGHT JOIN edu ON emp.id=edu.emp');
//var emps53 = alasql('SELECT * FROM emp OUTER JOIN family ON emp.id=family.emp LEFT JOIN addr ON emp.id=addr.emp INNER JOIN edu ON emp.id=edu.emp');
//var emps54 = alasql('SELECT * FROM emp OUTER JOIN family ON emp.id=family.emp LEFT JOIN addr ON emp.id=addr.emp OUTER JOIN edu ON emp.id=edu.emp');

//var emps81 = alasql('SELECT * FROM emp OUTER JOIN family ON emp.id=family.emp OUTER JOIN addr ON emp.id=addr.emp LEFT JOIN edu ON emp.id=edu.emp');
//var emps82 = alasql('SELECT * FROM emp OUTER JOIN family ON emp.id=family.emp OUTER JOIN addr ON emp.id=addr.emp RIGHT JOIN edu ON emp.id=edu.emp');
//var emps83 = alasql('SELECT * FROM emp OUTER JOIN family ON emp.id=family.emp OUTER JOIN addr ON emp.id=addr.emp INNER JOIN edu ON emp.id=edu.emp');
//var emps84 = alasql('SELECT * FROM emp OUTER JOIN family ON emp.id=family.emp OUTER JOIN addr ON emp.id=addr.emp OUTER JOIN edu ON emp.id=edu.emp');

*/////////////////////////////////////////////////////////////








//var EventUtil = {
//
//	    addHandler: function(element, type, handler){
//	        if (element.addEventListener){
//	            element.addEventListener(type, handler, false);
//	        } else if (element.attachEvent){
//	            element.attachEvent("on" + type, handler);
//	        } else {
//	            element["on" + type] = handler;
//	        }
//	    },
//	    
//	    getButton: function(event){
//	        if (document.implementation.hasFeature("MouseEvents", "2.0")){
//	            return event.button;
//	        } else {
//	            switch(event.button){
//	                case 0:
//	                case 1:
//	                case 3:
//	                case 5:
//	                case 7:
//	                    return 0;
//	                case 2:
//	                case 6:
//	                    return 2;
//	                case 4: return 1;
//	            }
//	        }
//	    },
//	    
//	    getCharCode: function(event){
//	        if (typeof event.charCode == "number"){
//	            return event.charCode;
//	        } else {
//	            return event.keyCode;
//	        }
//	    },
//	    
//	    getClipboardText: function(event){
//	        var clipboardData =  (event.clipboardData || window.clipboardData);
//	        return clipboardData.getData("text");
//	    },
//	    
//	    getEvent: function(event){
//	        return event ? event : window.event;
//	    },
//	    
//	    getRelatedTarget: function(event){
//	        if (event.relatedTarget){
//	            return event.relatedTarget;
//	        } else if (event.toElement){
//	            return event.toElement;
//	        } else if (event.fromElement){
//	            return event.fromElement;
//	        } else {
//	            return null;
//	        }
//	    
//	    },
//	    
//	    getTarget: function(event){
//	        return event.target || event.srcElement;
//	    },
//	    
//	    getWheelDelta: function(event){
//	        if (event.wheelDelta){
//	            return (client.engine.opera && client.engine.opera < 9.5 ? -event.wheelDelta : event.wheelDelta);
//	        } else {
//	            return -event.detail * 40;
//	        }
//	    },
//	    
//	    preventDefault: function(event){
//	        if (event.preventDefault){
//	            event.preventDefault();
//	        } else {
//	            event.returnValue = false;
//	        }
//	    },
//
//	    removeHandler: function(element, type, handler){
//	        if (element.removeEventListener){
//	            element.removeEventListener(type, handler, false);
//	        } else if (element.detachEvent){
//	            element.detachEvent("on" + type, handler);
//	        } else {
//	            element["on" + type] = null;
//	        }
//	    },
//	    
//	    setClipboardText: function(event, value){
//	        if (event.clipboardData){
//	            event.clipboardData.setData("text/plain", value);
//	        } else if (window.clipboardData){
//	            window.clipboardData.setData("text", value);
//	        }
//	    },
//	    
//	    stopPropagation: function(event){
//	        if (event.stopPropagation){
//	            event.stopPropagation();
//	        } else {
//	            event.cancelBubble = true;
//	        }
//	    }
//
//	};
//var textbox = document.getElementById("myText");
//EventUtil.addHandler(textbox, "keyup", function(event){
//event = EventUtil.getEvent(event);
//alert(event.keyCode);
//});
//
